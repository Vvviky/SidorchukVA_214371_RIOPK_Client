const config = {
  apiUrl: 'http://localhost:5001/api',
  authUrl: 'http://localhost:5000/api/auth'
};

export default config; 