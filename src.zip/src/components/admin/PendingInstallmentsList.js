import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  CircularProgress,
  Alert,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField
} from '@mui/material';
import { 
  fetchAdminInstallments, 
  updateInstallmentStatus 
} from '../../store/slices/installmentsSlice';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { showNotification } from '../Notification';

const PendingInstallmentsList = () => {
  const dispatch = useDispatch();
  const { adminInstallments, loading, error } = useSelector(state => state.installments);
  
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [selectedInstallment, setSelectedInstallment] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  
  // Получаем только рассрочки со статусом 'pending'
  const pendingInstallments = Array.isArray(adminInstallments) 
    ? adminInstallments.filter(installment => 
        installment.status === 'pending' || 
        installment.status === 'PENDING'
      ) 
    : [];
  
  useEffect(() => {
    dispatch(fetchAdminInstallments());
  }, [dispatch]);
  
  const handleApprove = async (installmentId) => {
    try {
      const resultAction = await dispatch(
        updateInstallmentStatus({ id: installmentId, status: 'approved' })
      );
      
      if (updateInstallmentStatus.fulfilled.match(resultAction)) {
        showNotification('Рассрочка успешно одобрена', 'success');
        dispatch(fetchAdminInstallments());
      }
    } catch (error) {
      console.error('Ошибка при одобрении рассрочки:', error);
      showNotification('Не удалось одобрить рассрочку', 'error');
    }
  };
  
  const openRejectDialog = (installment) => {
    setSelectedInstallment(installment);
    setRejectReason('');
    setRejectDialogOpen(true);
  };
  
  const handleReject = async () => {
    if (!selectedInstallment) return;
    
    try {
      const resultAction = await dispatch(
        updateInstallmentStatus({ 
          id: selectedInstallment.id, 
          status: 'rejected',
          reason: rejectReason.trim() || 'Отклонено администратором'
        })
      );
      
      if (updateInstallmentStatus.fulfilled.match(resultAction)) {
        showNotification('Рассрочка отклонена', 'info');
        setRejectDialogOpen(false);
        setSelectedInstallment(null);
        dispatch(fetchAdminInstallments());
      }
    } catch (error) {
      console.error('Ошибка при отклонении рассрочки:', error);
      showNotification('Не удалось отклонить рассрочку', 'error');
    }
  };
  
  const handleCloseDialog = () => {
    setRejectDialogOpen(false);
    setSelectedInstallment(null);
    setRejectReason('');
  };
  
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
        <CircularProgress />
      </Box>
    );
  }
  
  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Рассрочки, ожидающие одобрения
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      {pendingInstallments.length === 0 ? (
        <Alert severity="info">
          Нет рассрочек, ожидающих одобрения
        </Alert>
      ) : (
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Название</TableCell>
                <TableCell>Пользователь</TableCell>
                <TableCell>Сумма</TableCell>
                <TableCell>Срок (мес.)</TableCell>
                <TableCell>Дата создания</TableCell>
                <TableCell>Действия</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pendingInstallments.map((installment) => (
                <TableRow key={installment.id}>
                  <TableCell>{installment.id}</TableCell>
                  <TableCell>{installment.title}</TableCell>
                  <TableCell>{installment.user?.email || 'Неизвестно'}</TableCell>
                  <TableCell>{formatCurrency(installment.totalAmount)}</TableCell>
                  <TableCell>{installment.term}</TableCell>
                  <TableCell>{formatDate(installment.createdAt)}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        size="small"
                        variant="contained"
                        color="success"
                        onClick={() => handleApprove(installment.id)}
                      >
                        Одобрить
                      </Button>
                      <Button
                        size="small"
                        variant="outlined"
                        color="error"
                        onClick={() => openRejectDialog(installment)}
                      >
                        Отклонить
                      </Button>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      
      {/* Диалог отклонения рассрочки */}
      <Dialog
        open={rejectDialogOpen}
        onClose={handleCloseDialog}
      >
        <DialogTitle>Отклонение рассрочки</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Укажите причину отклонения рассрочки "{selectedInstallment?.title}".
            Пользователь получит уведомление с этой причиной.
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="Причина отклонения"
            fullWidth
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            multiline
            rows={3}
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Отмена</Button>
          <Button onClick={handleReject} color="error">
            Отклонить
          </Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default PendingInstallmentsList; 