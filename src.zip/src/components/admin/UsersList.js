import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Chip,
  MenuItem,
  Select,
  FormControl,
  Switch,
  CircularProgress,
  Alert,
  Box,
  Typography,
  Button
} from '@mui/material';
import { 
  fetchAllUsers, 
  updateUserRole, 
  updateUserStatus 
} from '../../store/slices/authSlice';
import { showNotification } from '../Notification';

const UsersList = () => {
  const dispatch = useDispatch();
  const { users, usersLoading: loading, usersError: error } = useSelector(state => state.auth);

  useEffect(() => {
    dispatch(fetchAllUsers());
  }, [dispatch]);

  const handleRoleChange = async (userId, newRole) => {
    try {
      const resultAction = await dispatch(updateUserRole({ userId, role: newRole }));
      
      if (updateUserRole.fulfilled.match(resultAction)) {
        showNotification(`Роль пользователя изменена на "${newRole}"`, 'success');
      }
    } catch (err) {
      showNotification('Ошибка при обновлении роли пользователя', 'error');
    }
  };

  const handleStatusChange = async (userId, newStatus) => {
    try {
      const resultAction = await dispatch(updateUserStatus({ userId, isActive: newStatus }));
      
      if (updateUserStatus.fulfilled.match(resultAction)) {
        showNotification(`Статус пользователя ${newStatus ? 'активирован' : 'деактивирован'}`, 'success');
      }
    } catch (err) {
      showNotification('Ошибка при обновлении статуса пользователя', 'error');
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'admin':
        return 'error';
      case 'manager':
        return 'warning';
      default:
        return 'primary';
    }
  };

  const handleRefresh = () => {
    dispatch(fetchAllUsers());
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">
          Список пользователей
        </Typography>
        <Button 
          variant="contained"
          color="primary"
          onClick={handleRefresh}
        >
          Обновить
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Имя</TableCell>
              <TableCell>Фамилия</TableCell>
              <TableCell>Роль</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users && users.length > 0 ? (
              users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.firstName || '-'}</TableCell>
                  <TableCell>{user.lastName || '-'}</TableCell>
                  <TableCell>
                    <Chip 
                      label={user.role} 
                      color={getRoleColor(user.role)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Switch 
                      checked={user.isActive}
                      onChange={(e) => handleStatusChange(user.id, e.target.checked)}
                      color="success"
                    />
                  </TableCell>
                  <TableCell>
                    <FormControl size="small">
                      <Select
                        value={user.role}
                        onChange={(e) => handleRoleChange(user.id, e.target.value)}
                        size="small"
                      >
                        <MenuItem value="user">Пользователь</MenuItem>
                        <MenuItem value="manager">Менеджер</MenuItem>
                        <MenuItem value="admin">Администратор</MenuItem>
                      </Select>
                    </FormControl>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  Нет пользователей для отображения
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default UsersList; 