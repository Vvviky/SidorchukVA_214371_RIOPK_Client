import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Alert,
  IconButton,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Tooltip
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';
import axios from 'axios';

// Настройка API
const BUSINESS_API_URL = process.env.REACT_APP_BUSINESS_SERVICE_URL || 'http://localhost:5001/api';
const businessApi = axios.create({
  baseURL: BUSINESS_API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Добавление токена авторизации к запросам
businessApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

const PaymentsList = () => {
  const { installmentId } = useParams();
  const [payments, setPayments] = useState([]);
  const [installment, setInstallment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updateStatusDialogOpen, setUpdateStatusDialogOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [newStatus, setNewStatus] = useState('');

  useEffect(() => {
    fetchData();
  }, [installmentId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      let paymentsResponse;
      
      if (installmentId) {
        // Загружаем платежи для конкретной рассрочки
        paymentsResponse = await businessApi.get(`/payments/installment/${installmentId}`);
        
        // Также загружаем информацию о самой рассрочке
        const installmentResponse = await businessApi.get(`/installments/${installmentId}`);
        setInstallment(installmentResponse.data);
      } else {
        // Загружаем все платежи
        paymentsResponse = await businessApi.get('/payments/admin');
      }
      
      // Обработка ответа API
      const paymentsData = paymentsResponse.data?.data || paymentsResponse.data || [];
      setPayments(Array.isArray(paymentsData) ? paymentsData : []);
      setLoading(false);
    } catch (err) {
      console.error('Ошибка при загрузке платежей:', err);
      setError('Не удалось загрузить список платежей. Пожалуйста, попробуйте позже.');
      setLoading(false);
    }
  };

  const handleUpdateStatusClick = (payment, status) => {
    setSelectedPayment(payment);
    setNewStatus(status);
    setUpdateStatusDialogOpen(true);
  };

  const handleUpdateStatus = async () => {
    if (!selectedPayment || !newStatus) return;
    
    try {
      await businessApi.patch(`/payments/${selectedPayment.id}/status`, { status: newStatus });
      setUpdateStatusDialogOpen(false);
      fetchData(); // Обновляем список после изменения статуса
    } catch (err) {
      console.error('Ошибка при обновлении статуса платежа:', err);
      setError('Не удалось обновить статус платежа. Пожалуйста, попробуйте позже.');
    }
  };

  const getStatusChip = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return <Chip label="Ожидает оплаты" color="warning" size="small" />;
      case 'paid':
        return <Chip label="Оплачен" color="success" size="small" />;
      case 'overdue':
        return <Chip label="Просрочен" color="error" size="small" />;
      case 'cancelled':
        return <Chip label="Отменен" color="default" size="small" />;
      default:
        return <Chip label={status || 'Неизвестно'} color="default" size="small" />;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    
    try {
      const date = new Date(dateString);
      
      // Проверка, что дата действительна
      if (isNaN(date.getTime())) {
        return '—';
      }
      
      return new Intl.DateTimeFormat('ru-RU').format(date);
    } catch (error) {
      console.error('Ошибка форматирования даты:', error);
      return '—';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        {installment 
          ? `Платежи по рассрочке: ${installment.title}` 
          : 'Управление платежами'}
      </Typography>
      
      {installment && (
        <Box sx={{ mb: 3 }}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6">Информация о рассрочке</Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', mt: 2, gap: 2 }}>
              <Box>
                <Typography variant="body2" color="textSecondary">Общая сумма</Typography>
                <Typography variant="body1">{installment.totalAmount} BYN</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="textSecondary">Срок (мес.)</Typography>
                <Typography variant="body1">{installment.term}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="textSecondary">Статус</Typography>
                <Typography variant="body1">{getStatusChip(installment.status)}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="textSecondary">Оплачено</Typography>
                <Typography variant="body1">{installment.paidAmount || 0} BYN</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="textSecondary">Осталось</Typography>
                <Typography variant="body1">{(installment.totalAmount - (installment.paidAmount || 0)).toFixed(2)} BYN</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="textSecondary">Дата создания</Typography>
                <Typography variant="body1">{formatDate(installment.createdAt)}</Typography>
              </Box>
            </Box>
          </Paper>
        </Box>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      {payments.length === 0 ? (
        <Alert severity="info">
          Платежи не найдены
        </Alert>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                {!installmentId && <TableCell>Рассрочка</TableCell>}
                <TableCell>Сумма</TableCell>
                <TableCell>Статус</TableCell>
                <TableCell>Срок оплаты</TableCell>
                <TableCell>Оплачено</TableCell>
                <TableCell>Действия</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {payments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell>{String(payment.id).substring(0, 8)}...</TableCell>
                  {!installmentId && (
                    <TableCell>
                      {payment.installment?.title || payment.installmentId}
                    </TableCell>
                  )}
                  <TableCell>{payment.amount} BYN</TableCell>
                  <TableCell>{getStatusChip(payment.status)}</TableCell>
                  <TableCell>{formatDate(payment.dueDate)}</TableCell>
                  <TableCell>{formatDate(payment.paidAt) || '—'}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      {payment.status !== 'paid' && (
                        <Tooltip title="Отметить как оплаченный">
                          <IconButton
                            color="success"
                            size="small"
                            onClick={() => handleUpdateStatusClick(payment, 'paid')}
                          >
                            <CheckCircleIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                      
                      {payment.status === 'pending' && (
                        <Tooltip title="Отметить как просроченный">
                          <IconButton
                            color="error"
                            size="small"
                            onClick={() => handleUpdateStatusClick(payment, 'overdue')}
                          >
                            <DoNotDisturbIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      
      {/* Диалог изменения статуса платежа */}
      <Dialog open={updateStatusDialogOpen} onClose={() => setUpdateStatusDialogOpen(false)}>
        <DialogTitle>Изменение статуса платежа</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Вы уверены, что хотите изменить статус платежа на "{
              newStatus === 'paid' ? 'Оплачен' :
              newStatus === 'overdue' ? 'Просрочен' : newStatus
            }"?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUpdateStatusDialogOpen(false)}>Отмена</Button>
          <Button onClick={handleUpdateStatus} color="primary">Подтвердить</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PaymentsList; 