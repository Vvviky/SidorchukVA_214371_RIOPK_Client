import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Divider,
} from '@mui/material';
import {
  PeopleAlt as PeopleIcon,
  Dashboard as DashboardIcon,
  ListAlt as TemplatesIcon,
  Payments as PaymentsIcon,
  BarChart as StatsIcon,
  Settings as SettingsIcon,
  CreditCard as CardIcon
} from '@mui/icons-material';
import Statistics from './Statistics';
import PendingInstallmentsList from './PendingInstallmentsList';

// Компонент карточки для секции администрирования
const AdminCard = ({ title, description, icon: Icon, path, color }) => {
  const navigate = useNavigate();
  
  return (
    <Card sx={{ 
      height: '100%', 
      display: 'flex', 
      flexDirection: 'column',
      transition: 'transform 0.2s, box-shadow 0.2s',
      '&:hover': {
        transform: 'translateY(-4px)',
        boxShadow: 6
      }
    }}>
      <CardContent sx={{ flexGrow: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Icon sx={{ fontSize: 40, color: `${color}.main`, mr: 1 }} />
          <Typography variant="h5" component="h2">
            {title}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary">
          {description}
        </Typography>
      </CardContent>
      <CardActions>
        <Button 
          size="medium" 
          color={color} 
          variant="contained" 
          fullWidth
          onClick={() => navigate(path)}
        >
          Перейти
        </Button>
      </CardActions>
    </Card>
  );
};

const AdminDashboard = () => {
  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ 
          borderLeft: '4px solid #1976d2', 
          pl: 2,
          mb: 3
        }}>
          Панель администратора
        </Typography>
        
        <Typography variant="body1" paragraph>
          Добро пожаловать в панель администратора Smart Split. Здесь вы можете управлять пользователями, рассрочками, шаблонами и просматривать статистику системы.
        </Typography>
        
        <Grid container spacing={4} sx={{ mt: 1 }}>
          <Grid item xs={12} md={4}>
            <AdminCard
              title="Пользователи"
              description="Управление пользователями системы, изменение ролей и статусов"
              icon={PeopleIcon}
              path="/admin/users"
              color="primary"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <AdminCard
              title="Рассрочки"
              description="Просмотр и управление всеми рассрочками в системе"
              icon={PaymentsIcon}
              path="/admin/installments"
              color="secondary"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <AdminCard
              title="Шаблоны"
              description="Создание и редактирование шаблонов рассрочек для пользователей"
              icon={TemplatesIcon}
              path="/admin/templates"
              color="success"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <AdminCard
              title="Платежи"
              description="Просмотр и управление платежами в системе"
              icon={CardIcon}
              path="/admin/payments"
              color="warning"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <AdminCard
              title="Статистика"
              description="Просмотр подробной статистики системы и аналитических данных"
              icon={StatsIcon}
              path="/admin/stats"
              color="info"
            />
          </Grid>
          {/* В будущем можно добавить дополнительные карточки для новых функций */}
        </Grid>
      </Paper>
      
      {/* Секция рассрочек, ожидающих одобрения */}
      <PendingInstallmentsList />
      
      <Divider sx={{ mb: 4 }} />
      
      {/* Секция статистики */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>
          Краткая статистика
        </Typography>
        <Statistics />
      </Paper>
    </Container>
  );
};

export default AdminDashboard; 