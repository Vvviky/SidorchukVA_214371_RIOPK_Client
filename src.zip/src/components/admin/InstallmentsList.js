import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Chip,
  Alert,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
  IconButton,
  Tooltip,
  Tab,
  Tabs
} from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import PaymentIcon from '@mui/icons-material/Payment';
import VisibilityIcon from '@mui/icons-material/Visibility';
import InfoIcon from '@mui/icons-material/Info';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { 
  fetchAdminInstallments, 
  updateInstallmentStatus 
} from '../../store/slices/installmentsSlice';
import { showNotification } from '../Notification';

// Настройка API
const BUSINESS_API_URL = process.env.REACT_APP_BUSINESS_SERVICE_URL || 'http://localhost:5001/api';
const businessApi = axios.create({
  baseURL: BUSINESS_API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Добавление токена авторизации к запросам
businessApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

const InstallmentsList = () => {
  const dispatch = useDispatch();
  const { adminInstallments, loading, error } = useSelector(state => state.installments);
  
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [selectedInstallment, setSelectedInstallment] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [currentTab, setCurrentTab] = useState(0);

  useEffect(() => {
    loadInstallments();
  }, [dispatch]);

  const loadInstallments = () => {
    dispatch(fetchAdminInstallments())
      .unwrap()
      .catch(error => {
        console.error('Ошибка загрузки рассрочек:', error);
      });
  };

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
  };

  const handleStatusChange = (id, newStatus) => {
    dispatch(updateInstallmentStatus({ id, status: newStatus }))
      .unwrap()
      .then(() => {
        showNotification(`Статус рассрочки успешно изменен на "${newStatus}"`, 'success');
        loadInstallments();
      })
      .catch(error => {
        console.error('Ошибка обновления статуса:', error);
        showNotification(`Ошибка при обновлении статуса: ${error}`, 'error');
      });
  };

  const handleRejectClick = (installment) => {
    setSelectedInstallment(installment);
    setRejectionReason('');
    setRejectDialogOpen(true);
  };

  const handleRejectConfirm = () => {
    dispatch(updateInstallmentStatus({ 
      id: selectedInstallment.id, 
      status: 'rejected', 
      reason: rejectionReason 
    }))
      .unwrap()
      .then(() => {
        showNotification('Рассрочка отклонена', 'success');
        setRejectDialogOpen(false);
        loadInstallments();
      })
      .catch(error => {
        console.error('Ошибка отклонения рассрочки:', error);
        showNotification(`Ошибка при отклонении рассрочки: ${error}`, 'error');
      });
  };

  const handlePaymentClick = (installment) => {
    setSelectedInstallment(installment);
    setPaymentAmount('');
    setPaymentDialogOpen(true);
  };

  const handlePaymentConfirm = async () => {
    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      showNotification('Введите корректную сумму платежа', 'error');
      return;
    }

    try {
      // Вызов API для создания платежа
      const response = await businessApi.post('/payments/simulate', {
        installmentId: selectedInstallment.id,
        amount: amount
      });
      
      console.log('Ответ от сервера:', response.data);
      
      showNotification(`Платеж на сумму ${amount} BYN успешно создан`, 'success');
      setPaymentDialogOpen(false);
      
      // Обновляем список рассрочек, чтобы отобразить изменения
      loadInstallments();
    } catch (error) {
      console.error('Ошибка при создании платежа:', error);
      showNotification(`Ошибка при создании платежа: ${error.response?.data?.message || error.message}`, 'error');
    }
  };

  const getStatusChip = (status) => {
    const statusConfig = {
      pending: { label: 'На рассмотрении', color: 'warning' },
      approved: { label: 'Одобрена', color: 'info' },
      active: { label: 'Активна', color: 'primary' },
      completed: { label: 'Завершена', color: 'success' },
      rejected: { label: 'Отклонена', color: 'error' },
      cancelled: { label: 'Отменена', color: 'default' }
    };

    const config = statusConfig[status] || { label: status || 'Неизвестно', color: 'default' };
    return <Chip label={config.label} color={config.color} />;
  };

  // Фильтрация рассрочек по вкладке
  const getFilteredInstallments = () => {
    if (!Array.isArray(adminInstallments)) return [];
    
    switch(currentTab) {
      case 0: // Все рассрочки
        return adminInstallments;
      case 1: // На рассмотрении
        return adminInstallments.filter(i => i.status === 'pending');
      case 2: // Одобренные
        return adminInstallments.filter(i => i.status === 'approved');
      case 3: // Активные
        return adminInstallments.filter(i => i.status === 'active');
      case 4: // Завершенные/Отклоненные
        return adminInstallments.filter(i => 
          i.status === 'completed' || 
          i.status === 'rejected' || 
          i.status === 'cancelled'
        );
      default:
        return adminInstallments;
    }
  };

  if (loading) return (
    <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
      <CircularProgress />
    </Box>
  );

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        Управление рассрочками
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs value={currentTab} onChange={handleTabChange}>
          <Tab label="Все" />
          <Tab label="На рассмотрении" />
          <Tab label="Одобренные" />
          <Tab label="Активные" />
          <Tab label="Завершенные/Отклоненные" />
        </Tabs>
      </Box>
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Название</TableCell>
              <TableCell>Пользователь</TableCell>
              <TableCell>Сумма</TableCell>
              <TableCell>Срок (мес)</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Дата создания</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {getFilteredInstallments().length > 0 ? (
              getFilteredInstallments().map((installment) => (
                <TableRow key={installment.id ? installment.id.toString() : `item-${Math.random()}`}>
                  <TableCell>
                    {installment.id ? 
                      (typeof installment.id === 'string' ? 
                        installment.id.substring(0, 8) : 
                        String(installment.id).substring(0, 8)) 
                      : 'Н/Д'}...
                  </TableCell>
                  <TableCell>{installment.title}</TableCell>
                  <TableCell>{installment.userId || 'Н/Д'}</TableCell>
                  <TableCell>{installment.totalAmount} BYN</TableCell>
                  <TableCell>{installment.term}</TableCell>
                  <TableCell>{getStatusChip(installment.status)}</TableCell>
                  <TableCell>
                    {installment.createdAt ? new Date(installment.createdAt).toLocaleDateString() : 'Н/Д'}
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      {installment.status === 'pending' && (
                        <>
                          <Tooltip title="Одобрить">
                            <IconButton
                              color="success"
                              size="small"
                              onClick={() => handleStatusChange(installment.id, 'approved')}
                            >
                              <CheckCircleIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Отклонить">
                            <IconButton
                              color="error"
                              size="small"
                              onClick={() => handleRejectClick(installment)}
                            >
                              <CancelIcon />
                            </IconButton>
                          </Tooltip>
                        </>
                      )}
                      
                      {installment.status === 'approved' && (
                        <Tooltip title="Активировать">
                          <IconButton
                            color="primary"
                            size="small"
                            onClick={() => handleStatusChange(installment.id, 'active')}
                          >
                            <PlayArrowIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                      
                      {installment.status === 'active' && (
                        <>
                          <Tooltip title="Добавить платеж">
                            <IconButton
                              color="info"
                              size="small"
                              onClick={() => handlePaymentClick(installment)}
                            >
                              <PaymentIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Детали платежей">
                            <IconButton
                              color="primary"
                              size="small"
                              component={Link}
                              to={`/admin/installments/${installment.id}/payments`}
                            >
                              <VisibilityIcon />
                            </IconButton>
                          </Tooltip>
                        </>
                      )}
                      
                      {/* Кнопка просмотра деталей для всех статусов */}
                      <Tooltip title="Детали рассрочки">
                        <IconButton
                          color="info"
                          size="small"
                          component={Link}
                          to={`/admin/installments/${installment.id}`}
                        >
                          <InfoIcon />
                        </IconButton>
                      </Tooltip>
                      
                      {installment.status !== 'completed' && installment.status !== 'rejected' && (
                        <Tooltip title="Отменить">
                          <IconButton
                            color="default"
                            size="small"
                            onClick={() => handleStatusChange(installment.id, 'cancelled')}
                          >
                            <CancelIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Typography>Нет доступных рассрочек</Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      
      {/* Диалог отклонения рассрочки */}
      <Dialog open={rejectDialogOpen} onClose={() => setRejectDialogOpen(false)}>
        <DialogTitle>Отклонение рассрочки</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Укажите причину отклонения рассрочки
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="Причина отклонения"
            type="text"
            fullWidth
            variant="outlined"
            value={rejectionReason}
            onChange={(e) => setRejectionReason(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectDialogOpen(false)}>Отмена</Button>
          <Button onClick={handleRejectConfirm} color="error">Отклонить</Button>
        </DialogActions>
      </Dialog>
      
      {/* Диалог добавления платежа */}
      <Dialog open={paymentDialogOpen} onClose={() => setPaymentDialogOpen(false)}>
        <DialogTitle>Добавление платежа</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Введите сумму платежа по рассрочке
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="Сумма платежа"
            type="number"
            fullWidth
            variant="outlined"
            value={paymentAmount}
            onChange={(e) => setPaymentAmount(e.target.value)}
            InputProps={{ inputProps: { min: 0 } }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPaymentDialogOpen(false)}>Отмена</Button>
          <Button onClick={handlePaymentConfirm} color="primary">Добавить</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default InstallmentsList; 