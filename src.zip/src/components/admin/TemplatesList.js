import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Alert,
  CircularProgress,
  FormGroup,
  FormControlLabel,
  Checkbox
} from '@mui/material';
import { 
  fetchAllTemplates, 
  createTemplate, 
  updateTemplate, 
  deleteTemplate,
  toggleTemplateStatus
} from '../../store/slices/templatesSlice';
import { showNotification } from '../Notification';

const TemplatesList = () => {
  const dispatch = useDispatch();
  const { templates, loading, error } = useSelector(state => state.templates);
  
  const [openDialog, setOpenDialog] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState({
    name: '',
    description: '',
    minAmount: 100,
    maxAmount: 10000,
    defaultAmount: 5000,
    availableTerms: [3, 6, 12],
    defaultTerm: 6,
    interestRate: 0,
    currency: 'RUB',
    requiresApproval: true,
    isActive: true,
    category: 'Другое'
  });
  
  useEffect(() => {
    dispatch(fetchAllTemplates());
  }, [dispatch]);
  
  const handleOpenDialog = (template = null) => {
    if (template) {
      setCurrentTemplate(template);
    } else {
      setCurrentTemplate({
        name: '',
        description: '',
        minAmount: 100,
        maxAmount: 10000,
        defaultAmount: 5000,
        availableTerms: [3, 6, 12],
        defaultTerm: 6,
        interestRate: 0,
        currency: 'RUB',
        requiresApproval: true,
        isActive: true,
        category: 'Другое'
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === 'checkbox') {
      setCurrentTemplate({
        ...currentTemplate,
        [name]: checked
      });
    } else {
      setCurrentTemplate({
        ...currentTemplate,
        [name]: value
      });
    }
  };

  const handleTermChange = (e, term) => {
    const currentTerms = [...currentTemplate.availableTerms];
    if (e.target.checked) {
      if (!currentTerms.includes(term)) {
        currentTerms.push(term);
      }
    } else {
      const index = currentTerms.indexOf(term);
      if (index !== -1) {
        currentTerms.splice(index, 1);
      }
    }
    setCurrentTemplate({
      ...currentTemplate,
      availableTerms: currentTerms
    });
  };

  const handleSubmit = async () => {
    try {
      // Преобразуем числовые поля
      const templateData = {
        ...currentTemplate,
        minAmount: parseFloat(currentTemplate.minAmount),
        maxAmount: parseFloat(currentTemplate.maxAmount),
        defaultAmount: parseFloat(currentTemplate.defaultAmount),
        interestRate: parseFloat(currentTemplate.interestRate),
        defaultTerm: parseInt(currentTemplate.defaultTerm)
      };

      let resultAction;
      
      if (currentTemplate.id) {
        // Обновление шаблона через Redux
        resultAction = await dispatch(updateTemplate({ 
          id: currentTemplate.id, 
          data: templateData 
        }));
        
        if (updateTemplate.fulfilled.match(resultAction)) {
          showNotification('Шаблон успешно обновлен', 'success');
        }
      } else {
        // Создание шаблона через Redux
        resultAction = await dispatch(createTemplate(templateData));
        
        if (createTemplate.fulfilled.match(resultAction)) {
          showNotification('Шаблон успешно создан', 'success');
        }
      }
      
      if (resultAction.error) {
        showNotification(resultAction.error.message || 'Ошибка при сохранении шаблона', 'error');
      }
      
      handleCloseDialog();
    } catch (err) {
      showNotification('Ошибка при сохранении шаблона', 'error');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить этот шаблон?')) {
      try {
        const resultAction = await dispatch(deleteTemplate(id));
        
        if (deleteTemplate.fulfilled.match(resultAction)) {
          showNotification('Шаблон успешно удален', 'success');
        } else if (resultAction.error) {
          showNotification(resultAction.error.message || 'Ошибка при удалении шаблона', 'error');
        }
      } catch (err) {
        showNotification('Ошибка при удалении шаблона', 'error');
      }
    }
  };
  
  const handleToggleStatus = async (id, isActive) => {
    try {
      const resultAction = await dispatch(toggleTemplateStatus({ id, isActive: !isActive }));
      
      if (toggleTemplateStatus.fulfilled.match(resultAction)) {
        showNotification(
          `Шаблон ${!isActive ? 'активирован' : 'деактивирован'}`, 
          'success'
        );
      } else if (resultAction.error) {
        showNotification(resultAction.error.message || 'Ошибка при изменении статуса шаблона', 'error');
      }
    } catch (err) {
      showNotification('Ошибка при изменении статуса шаблона', 'error');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <CircularProgress />
      </Box>
    );
  }

  const availableTermsOptions = [1, 3, 6, 12, 18, 24, 36, 48, 60];
  const categoryOptions = ['Бытовая техника', 'Электроника', 'Мебель', 'Образование', 'Путешествия', 'Другое'];

  return (
    <Box sx={{ mt: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Шаблоны рассрочек</Typography>
        <Button 
          variant="contained" 
          color="primary"
          onClick={() => handleOpenDialog()}
        >
          Создать шаблон
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Название</TableCell>
              <TableCell>Мин/Макс сумма</TableCell>
              <TableCell>Срок</TableCell>
              <TableCell>Ставка</TableCell>
              <TableCell>Категория</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {templates && templates.length > 0 ? (
              templates.map((template) => (
                <TableRow key={template.id}>
                  <TableCell>{template.name}</TableCell>
                  <TableCell>
                    {template.minAmount} - {template.maxAmount} {template.currency}
                  </TableCell>
                  <TableCell>
                    {template.availableTerms.join(', ')} мес.
                    <div>
                      <small>По умолчанию: {template.defaultTerm} мес.</small>
                    </div>
                  </TableCell>
                  <TableCell>{template.interestRate}%</TableCell>
                  <TableCell>{template.category}</TableCell>
                  <TableCell>
                    <Chip 
                      label={template.isActive ? 'Активен' : 'Неактивен'} 
                      color={template.isActive ? 'success' : 'default'}
                      size="small"
                      onClick={() => handleToggleStatus(template.id, template.isActive)}
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outlined"
                      color="primary"
                      onClick={() => handleOpenDialog(template)}
                      sx={{ mr: 1 }}
                    >
                      Изменить
                    </Button>
                    <Button
                      variant="outlined"
                      color="error"
                      onClick={() => handleDelete(template.id)}
                    >
                      Удалить
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  Нет шаблонов для отображения
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      
      <Dialog 
        open={openDialog} 
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          {currentTemplate.id ? 'Редактировать шаблон' : 'Создать шаблон'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <TextField
              label="Название"
              name="name"
              value={currentTemplate.name}
              onChange={handleInputChange}
              fullWidth
              required
              margin="normal"
            />
            
            <TextField
              label="Описание"
              name="description"
              value={currentTemplate.description}
              onChange={handleInputChange}
              fullWidth
              multiline
              rows={3}
              margin="normal"
            />
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, my: 2 }}>
              <TextField
                label="Минимальная сумма"
                name="minAmount"
                type="number"
                value={currentTemplate.minAmount}
                onChange={handleInputChange}
                required
                sx={{ flexGrow: 1 }}
              />
              
              <TextField
                label="Максимальная сумма"
                name="maxAmount"
                type="number"
                value={currentTemplate.maxAmount}
                onChange={handleInputChange}
                required
                sx={{ flexGrow: 1 }}
              />
              
              <TextField
                label="Сумма по умолчанию"
                name="defaultAmount"
                type="number"
                value={currentTemplate.defaultAmount}
                onChange={handleInputChange}
                required
                sx={{ flexGrow: 1 }}
              />
            </Box>
            
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1" gutterBottom>
                Доступные сроки (месяцев)
              </Typography>
              <FormGroup row>
                {availableTermsOptions.map(term => (
                  <FormControlLabel
                    key={term}
                    control={
                      <Checkbox
                        checked={currentTemplate.availableTerms.includes(term)}
                        onChange={(e) => handleTermChange(e, term)}
                      />
                    }
                    label={term}
                  />
                ))}
              </FormGroup>
            </Box>
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mt: 2 }}>
              <TextField
                label="Срок по умолчанию (мес.)"
                name="defaultTerm"
                type="number"
                value={currentTemplate.defaultTerm}
                onChange={handleInputChange}
                required
                sx={{ flexGrow: 1 }}
              />
              
              <TextField
                label="Процентная ставка"
                name="interestRate"
                type="number"
                value={currentTemplate.interestRate}
                onChange={handleInputChange}
                required
                sx={{ flexGrow: 1 }}
              />
              
              <FormControl sx={{ flexGrow: 1 }}>
                <InputLabel>Категория</InputLabel>
                <Select
                  name="category"
                  value={currentTemplate.category}
                  onChange={handleInputChange}
                  label="Категория"
                >
                  {categoryOptions.map(category => (
                    <MenuItem key={category} value={category}>
                      {category}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
            
            <Box sx={{ mt: 2 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="requiresApproval"
                    checked={currentTemplate.requiresApproval}
                    onChange={handleInputChange}
                  />
                }
                label="Требует одобрения"
              />
              
              <FormControlLabel
                control={
                  <Checkbox
                    name="isActive"
                    checked={currentTemplate.isActive}
                    onChange={handleInputChange}
                  />
                }
                label="Активен"
              />
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Отмена</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Сохранить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TemplatesList; 