import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  CircularProgress,
  Alert
} from '@mui/material';
import { 
  MonetizationOn as MoneyIcon,
  People as PeopleIcon,
  Assignment as InstallmentIcon,
  Payment as PaymentIcon 
} from '@mui/icons-material';
import { fetchAllUsers } from '../../store/slices/authSlice';
import { fetchAdminInstallments } from '../../store/slices/installmentsSlice';
import { fetchUserPayments } from '../../store/slices/paymentsSlice';

const StatCard = ({ title, value, icon: Icon }) => (
  <Card>
    <CardContent>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <Icon sx={{ mr: 1, color: 'primary.main' }} />
        <Typography variant="h6" component="div">
          {title}
        </Typography>
      </Box>
      <Typography variant="h4" component="div">
        {value}
      </Typography>
    </CardContent>
  </Card>
);

const Statistics = () => {
  const dispatch = useDispatch();
  const { users } = useSelector(state => state.auth);
  const { adminInstallments, loading: installmentsLoading, error: installmentsError } = useSelector(state => state.installments);
  const { payments, loading: paymentsLoading, error: paymentsError } = useSelector(state => state.payments);
  
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeInstallments: 0,
    totalAmount: 0,
    successfulPayments: 0
  });
  
  const loading = installmentsLoading || paymentsLoading;
  const error = installmentsError || paymentsError;

  useEffect(() => {
    dispatch(fetchAllUsers());
    dispatch(fetchAdminInstallments());
    dispatch(fetchUserPayments());
  }, [dispatch]);
  
  useEffect(() => {
    if (users && adminInstallments && payments) {
      const activeInstallments = adminInstallments.filter(i => i.status === 'active');
      const totalAmount = activeInstallments.reduce((sum, i) => sum + i.totalAmount, 0);
      const successfulPayments = payments.filter(p => p.status === 'paid').length;
      
      setStats({
        totalUsers: users.length,
        activeInstallments: activeInstallments.length,
        totalAmount,
        successfulPayments
      });
    }
  }, [users, adminInstallments, payments]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        Статистика системы
      </Typography>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Пользователей"
            value={stats.totalUsers}
            icon={PeopleIcon}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Активных рассрочек"
            value={stats.activeInstallments}
            icon={InstallmentIcon}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Общая сумма"
            value={`${stats.totalAmount.toLocaleString()} BYN`}
            icon={MoneyIcon}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Успешных платежей"
            value={stats.successfulPayments}
            icon={PaymentIcon}
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default Statistics; 