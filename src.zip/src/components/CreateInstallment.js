import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert,
  Divider,
  InputAdornment
} from '@mui/material';
import { createInstallment } from '../store/slices/installmentsSlice';

const CreateInstallment = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { loading, error } = useSelector(state => state.installments);
  
  const [title, setTitle] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [term, setTerm] = useState('');
  const [paymentType, setPaymentType] = useState('equal'); // равные или дифференцированные платежи
  const [errors, setErrors] = useState({});
  const [schedulePreview, setSchedulePreview] = useState([]);
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!title.trim()) {
      newErrors.title = 'Введите название рассрочки';
    }
    
    if (!totalAmount || isNaN(totalAmount) || parseFloat(totalAmount) <= 0) {
      newErrors.totalAmount = 'Введите корректную сумму';
    }
    
    if (!term || isNaN(term) || parseInt(term) <= 0 || parseInt(term) > 60) {
      newErrors.term = 'Срок должен быть от 1 до 60 месяцев';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    const installmentData = {
      title,
      totalAmount: parseFloat(totalAmount),
      term: parseInt(term),
      paymentType
    };
    
    try {
      const resultAction = await dispatch(createInstallment(installmentData));
      
      if (createInstallment.fulfilled.match(resultAction)) {
        // Успешно создано - переходим на страницу рассрочек
        navigate('/installments');
      } else if (createInstallment.rejected.match(resultAction)) {
        // Ошибка уже будет в Redux, ничего делать не надо
        console.error('Ошибка при создании рассрочки:', resultAction.error);
      }
    } catch (error) {
      console.error('Непредвиденная ошибка:', error);
    }
  };
  
  const calculateSchedulePreview = () => {
    if (!totalAmount || isNaN(totalAmount) || !term || isNaN(term)) {
      setSchedulePreview([]);
      return;
    }
    
    const amount = parseFloat(totalAmount);
    const months = parseInt(term);
    
    if (amount <= 0 || months <= 0) {
      setSchedulePreview([]);
      return;
    }
    
    const today = new Date();
    const preview = [];
    
    if (paymentType === 'equal') {
      // Равные платежи
      const monthlyPayment = Math.round((amount / months) * 100) / 100;
      
      for (let i = 0; i < months; i++) {
        const paymentDate = new Date(today);
        paymentDate.setMonth(today.getMonth() + i + 1);
        
        preview.push({
          month: i + 1,
          amount: i === months - 1 ? amount - (monthlyPayment * (months - 1)) : monthlyPayment,
          date: paymentDate.toLocaleDateString('ru-RU')
        });
      }
    } else {
      // Дифференцированные платежи
      const principal = Math.round((amount / months) * 100) / 100;
      let remainingAmount = amount;
      
      for (let i = 0; i < months; i++) {
        const paymentDate = new Date(today);
        paymentDate.setMonth(today.getMonth() + i + 1);
        
        const currentPrincipal = i === months - 1 ? remainingAmount : principal;
        remainingAmount -= currentPrincipal;
        
        preview.push({
          month: i + 1,
          amount: currentPrincipal,
          date: paymentDate.toLocaleDateString('ru-RU')
        });
      }
    }
    
    setSchedulePreview(preview);
  };
  
  // Вызываем расчёт графика при изменении полей
  React.useEffect(() => {
    calculateSchedulePreview();
  }, [totalAmount, term, paymentType]);
  
  return (
    <Box sx={{ mt: 4, mb: 6 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 3 }}>
        Создание новой рассрочки
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }} elevation={3}>
            <Typography variant="h6" gutterBottom>
              Параметры рассрочки
            </Typography>
            <Divider sx={{ mb: 3 }} />
            
            <form onSubmit={handleSubmit}>
              <TextField
                label="Название рассрочки"
                fullWidth
                margin="normal"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                error={!!errors.title}
                helperText={errors.title}
                placeholder="Например: Покупка ноутбука"
              />
              
              <TextField
                label="Сумма"
                fullWidth
                margin="normal"
                type="number"
                value={totalAmount}
                onChange={(e) => setTotalAmount(e.target.value)}
                error={!!errors.totalAmount}
                helperText={errors.totalAmount}
                InputProps={{
                  endAdornment: <InputAdornment position="end">BYN</InputAdornment>,
                }}
              />
              
              <TextField
                label="Срок (месяцев)"
                fullWidth
                margin="normal"
                type="number"
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                error={!!errors.term}
                helperText={errors.term}
                inputProps={{ min: 1, max: 60 }}
              />
              
              <FormControl fullWidth margin="normal">
                <InputLabel id="payment-type-label">Тип платежей</InputLabel>
                <Select
                  labelId="payment-type-label"
                  value={paymentType}
                  label="Тип платежей"
                  onChange={(e) => setPaymentType(e.target.value)}
                >
                  <MenuItem value="equal">Равные платежи</MenuItem>
                  <MenuItem value="differential">Дифференцированные платежи</MenuItem>
                </Select>
              </FormControl>
              
              <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
                <Button 
                  variant="outlined"
                  onClick={() => navigate('/installments')}
                >
                  Отмена
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                >
                  {loading ? <CircularProgress size={24} /> : 'Создать рассрочку'}
                </Button>
              </Box>
            </form>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }} elevation={3}>
            <Typography variant="h6" gutterBottom>
              Предварительный график платежей
            </Typography>
            <Divider sx={{ mb: 3 }} />
            
            {schedulePreview.length > 0 ? (
              <Box sx={{ maxHeight: '400px', overflowY: 'auto' }}>
                {schedulePreview.map((payment) => (
                  <Box
                    key={payment.month}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      p: 1.5,
                      borderBottom: '1px solid #e0e0e0',
                      '&:last-child': {
                        borderBottom: 'none'
                      }
                    }}
                  >
                    <Typography>Платеж {payment.month}</Typography>
                    <Typography sx={{ mx: 2 }}>{payment.date}</Typography>
                    <Typography fontWeight="bold">{payment.amount.toFixed(2)} BYN</Typography>
                  </Box>
                ))}
              </Box>
            ) : (
              <Box sx={{ p: 3, textAlign: 'center' }}>
                <Typography color="textSecondary">
                  Заполните параметры рассрочки для расчета графика платежей
                </Typography>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default CreateInstallment; 