import React from 'react';
import './Loader.css';

const Loader = () => {
  return (
    <div className="loader-overlay">
      <div className="loader">
        <div className="loader-spinner"></div>
        <div className="loader-text">Загрузка...</div>
      </div>
    </div>
  );
};

export default Loader; 