import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Stepper,
  Step,
  StepLabel,
  CircularProgress,
  Alert,
  Card,
  CardContent,
  Divider,
  InputAdornment
} from '@mui/material';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import PaymentIcon from '@mui/icons-material/Payment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { createPayment } from '../store/slices/paymentsSlice';
import { fetchInstallmentDetails } from '../store/slices/installmentsSlice';
import { formatCurrency } from '../utils/formatters';

const PaymentSimulation = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { currentInstallment, loading: installmentLoading } = useSelector(state => state.installments);
  const { loading: paymentLoading, error: paymentError } = useSelector(state => state.payments);
  const { user } = useSelector(state => state.auth);
  
  const [activeStep, setActiveStep] = useState(0);
  const [amount, setAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('4444 3333 2222 1111');
  const [cardHolder, setCardHolder] = useState('');
  const [expiryDate, setExpiryDate] = useState('12/25');
  const [cvv, setCvv] = useState('123');
  const [errors, setErrors] = useState({});
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (id) {
      dispatch(fetchInstallmentDetails(id));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (currentInstallment) {
      // Установим остаток к оплате по умолчанию
      const remainingAmount = currentInstallment.totalAmount - (currentInstallment.paidAmount || 0);
      setAmount(remainingAmount.toString());
      
      // Заполним имя владельца карты из данных пользователя, если доступно
      if (user && user.name) {
        setCardHolder(user.name);
      }
    }
  }, [currentInstallment, user]);

  const steps = [
    'Данные платежа',
    'Ввод реквизитов',
    'Подтверждение',
    'Результат'
  ];

  const validateStep = () => {
    const newErrors = {};
    
    if (activeStep === 0) {
      if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
        newErrors.amount = 'Введите корректную сумму платежа';
      }
      
      if (currentInstallment) {
        const remainingAmount = currentInstallment.totalAmount - (currentInstallment.paidAmount || 0);
        if (parseFloat(amount) > remainingAmount) {
          newErrors.amount = `Сумма платежа не может превышать остаток по рассрочке (${formatCurrency(remainingAmount)})`;
        }
      }
    } else if (activeStep === 1) {
      if (!cardNumber.trim()) {
        newErrors.cardNumber = 'Введите номер карты';
      } else if (!/^\d{4} \d{4} \d{4} \d{4}$/.test(cardNumber)) {
        newErrors.cardNumber = 'Неверный формат номера карты';
      }
      
      if (!cardHolder.trim()) {
        newErrors.cardHolder = 'Введите имя владельца карты';
      }
      
      if (!expiryDate.trim()) {
        newErrors.expiryDate = 'Введите срок действия карты';
      } else if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
        newErrors.expiryDate = 'Неверный формат срока действия';
      }
      
      if (!cvv.trim()) {
        newErrors.cvv = 'Введите CVV код';
      } else if (!/^\d{3}$/.test(cvv)) {
        newErrors.cvv = 'CVV должен содержать 3 цифры';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      if (activeStep === 2) {
        handleSubmitPayment();
      } else {
        setActiveStep((prevStep) => prevStep + 1);
      }
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleSubmitPayment = async () => {
    setProcessing(true);
    
    try {
      // Имитация задержки обработки платежа
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Создание платежа
      const result = await dispatch(createPayment({
        installmentId: id,
        amount: parseFloat(amount)
      })).unwrap();
      
      console.log('Результат платежа:', result);
      
      // Обновляем текущую рассрочку
      if (result && result.installment) {
        console.log('Обновленные данные рассрочки:', result.installment);
        
        // Добавляем небольшую задержку перед обновлением данных рассрочки
        setTimeout(async () => {
          // Принудительно обновляем данные рассрочки с сервера с новым timestamp
          try {
            await dispatch(fetchInstallmentDetails(id));
            console.log('Рассрочка успешно обновлена после платежа');
          } catch (error) {
            console.error('Ошибка при обновлении данных рассрочки:', error);
          }
        }, 1000);
      }
      
      setSuccess(true);
      setActiveStep(3);
    } catch (error) {
      console.error('Ошибка при оплате:', error);
      setSuccess(false);
      setActiveStep(3);
    } finally {
      setProcessing(false);
    }
  };

  const handleFinish = () => {
    // Устанавливаем небольшую задержку и принудительно обновляем все рассрочки
    setTimeout(async () => {
      try {
        // Сначала обновляем текущую рассрочку
        await dispatch(fetchInstallmentDetails(id));
        console.log('Рассрочка успешно обновлена перед переходом на другую страницу');
      } catch (error) {
        console.error('Ошибка при обновлении рассрочки:', error);
      }
    }, 500);
    
    // Переходим на страницу с деталями рассрочки и перезагружаем страницу
    navigate(`/installments/${id}`, { replace: true });
    window.location.reload();
  };

  const formatCardNumber = (value) => {
    const input = value.replace(/\D/g, '');
    const groups = [];
    
    for (let i = 0; i < input.length; i += 4) {
      groups.push(input.slice(i, i + 4));
    }
    
    return groups.join(' ').slice(0, 19);
  };

  const handleCardNumberChange = (e) => {
    setCardNumber(formatCardNumber(e.target.value));
  };

  if (installmentLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (!currentInstallment) {
    return (
      <Box sx={{ mt: 4 }}>
        <Alert severity="error">Не удалось загрузить данные рассрочки</Alert>
      </Box>
    );
  }

  const remainingAmount = currentInstallment.totalAmount - (currentInstallment.paidAmount || 0);

  // Проверяем, можно ли производить платежи по этой рассрочке
  if (currentInstallment.status !== 'active' && currentInstallment.status !== 'approved') {
    return (
      <Box sx={{ mt: 4 }}>
        <Alert severity="warning">
          Оплата доступна только для активных рассрочек. 
          Текущий статус: {currentInstallment.status}
        </Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => navigate('/installments')}
        >
          Вернуться к списку рассрочек
        </Button>
      </Box>
    );
  }

  // Если вся сумма оплачена
  if (remainingAmount <= 0) {
    return (
      <Box sx={{ mt: 4 }}>
        <Alert severity="success">
          Рассрочка полностью оплачена!
        </Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => navigate('/installments')}
        >
          Вернуться к списку рассрочек
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>
          Оплата рассрочки
        </Typography>
        
        <Stepper activeStep={activeStep} sx={{ my: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {paymentError && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {paymentError}
          </Alert>
        )}
        
        {activeStep === 0 && (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Информация о рассрочке
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Название:</strong> {currentInstallment.title}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Общая сумма:</strong> {formatCurrency(currentInstallment.totalAmount)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Оплачено:</strong> {formatCurrency(currentInstallment.paidAmount || 0)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Осталось оплатить:</strong> {formatCurrency(remainingAmount)}
                      </Typography>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sx={{ mt: 2 }}>
              <TextField
                fullWidth
                label="Сумма платежа"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                error={!!errors.amount}
                helperText={errors.amount}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">BYN</InputAdornment>
                  ),
                }}
              />
            </Grid>
          </Grid>
        )}
        
        {activeStep === 1 && (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    <CreditCardIcon sx={{ mr: 1, verticalAlign: 'text-bottom' }} />
                    Данные банковской карты
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Номер карты"
                        value={cardNumber}
                        onChange={handleCardNumberChange}
                        error={!!errors.cardNumber}
                        helperText={errors.cardNumber}
                        placeholder="0000 0000 0000 0000"
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <CreditCardIcon />
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Имя владельца карты"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                        error={!!errors.cardHolder}
                        helperText={errors.cardHolder}
                        placeholder="IVAN IVANOV"
                      />
                    </Grid>
                    
                    <Grid item xs={6}>
                      <TextField
                        fullWidth
                        label="Срок действия"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        error={!!errors.expiryDate}
                        helperText={errors.expiryDate}
                        placeholder="ММ/ГГ"
                      />
                    </Grid>
                    
                    <Grid item xs={6}>
                      <TextField
                        fullWidth
                        label="CVV"
                        type="password"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                        error={!!errors.cvv}
                        helperText={errors.cvv}
                        inputProps={{ maxLength: 3 }}
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}
        
        {activeStep === 2 && (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    <PaymentIcon sx={{ mr: 1, verticalAlign: 'text-bottom' }} />
                    Подтверждение платежа
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Название рассрочки:</strong> {currentInstallment.title}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Сумма платежа:</strong> {formatCurrency(parseFloat(amount))}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Карта:</strong> **** **** **** {cardNumber.slice(-4)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="body1">
                        <strong>Владелец:</strong> {cardHolder}
                      </Typography>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="body2" color="text.secondary">
                        Нажмите "Оплатить", чтобы произвести платеж по рассрочке
                      </Typography>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}
        
        {activeStep === 3 && (
          <Grid container spacing={3} justifyContent="center">
            <Grid item xs={12} textAlign="center">
              {success ? (
                <>
                  <CheckCircleIcon color="success" sx={{ fontSize: 80, mb: 2 }} />
                  <Typography variant="h5" gutterBottom>
                    Платеж успешно выполнен!
                  </Typography>
                  <Typography variant="body1" paragraph>
                    Сумма: {formatCurrency(parseFloat(amount))}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Оплата по рассрочке "{currentInstallment.title}" успешно произведена. 
                    Остаток к оплате: {formatCurrency(remainingAmount - parseFloat(amount))}
                  </Typography>
                </>
              ) : (
                <>
                  <Typography variant="h5" color="error" gutterBottom>
                    Ошибка при выполнении платежа
                  </Typography>
                  <Typography variant="body1" paragraph>
                    Пожалуйста, попробуйте еще раз или обратитесь в поддержку.
                  </Typography>
                </>
              )}
            </Grid>
          </Grid>
        )}
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
          {activeStep !== 3 && (
            <Button
              disabled={activeStep === 0}
              onClick={handleBack}
              variant="outlined"
            >
              Назад
            </Button>
          )}
          
          <Button
            variant="contained"
            onClick={activeStep === 3 ? handleFinish : handleNext}
            disabled={processing}
          >
            {processing && <CircularProgress size={24} sx={{ mr: 1 }} />}
            {activeStep === 2 ? 'Оплатить' : 
             activeStep === 3 ? 'Завершить' : 'Далее'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
};

export default PaymentSimulation; 