import React from 'react';
import { Box, Paper, Typography } from '@mui/material';

const AuthFormContainer = ({ title, children }) => {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
        py: 4,
      }}
    >
      <Paper
        elevation={3}
        sx={{
          p: 4,
          width: '100%',
          maxWidth: 450,
          mx: 2,
          borderRadius: 2,
          background: 'rgba(255, 255, 255, 0.95)',
        }}
      >
        <Typography
          variant="h4"
          component="h1"
          gutterBottom
          align="center"
          sx={{ 
            mb: 4, 
            color: '#1976d2',
            fontWeight: 'bold',
          }}
        >
          {title}
        </Typography>
        {children}
      </Paper>
    </Box>
  );
};

export default AuthFormContainer; 