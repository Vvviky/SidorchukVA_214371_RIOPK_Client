import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  TextField,
  Button,
  CircularProgress,
  Link as MuiLink,
  Typography,
  Box,
} from '@mui/material';
import { authService } from '../../services/api';
import AuthFormContainer from './AuthFormContainer';

const RegisterForm = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (formData.password !== formData.confirmPassword) {
      setError('Пароли не совпадают');
      setLoading(false);
      return;
    }

    try {
      await authService.register({
        email: formData.email,
        password: formData.password,
        name: formData.name,
      });
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.message || 'Ошибка при регистрации');
    } finally {
      setLoading(false);
    }
  };

  const textFieldStyles = {
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: '#1976d2',
      },
      '&:hover fieldset': {
        borderColor: '#1565c0',
      },
    },
  };

  return (
    <AuthFormContainer title="Регистрация">
      <form onSubmit={handleSubmit}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          <TextField
            fullWidth
            label="Имя"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            size="medium"
            sx={textFieldStyles}
          />

          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
            size="medium"
            sx={textFieldStyles}
          />

          <TextField
            fullWidth
            label="Пароль"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            size="medium"
            sx={textFieldStyles}
          />

          <TextField
            fullWidth
            label="Подтверждение пароля"
            name="confirmPassword"
            type="password"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
            size="medium"
            sx={textFieldStyles}
          />

          {error && (
            <Typography color="error" align="center">
              {error}
            </Typography>
          )}

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            disabled={loading}
            size="large"
            sx={{ 
              py: 1.5,
              fontSize: '1.1rem',
              textTransform: 'none',
            }}
          >
            {loading ? <CircularProgress size={24} /> : 'Зарегистрироваться'}
          </Button>

          <Typography align="center" sx={{ mt: 2 }}>
            Уже есть аккаунт?{' '}
            <MuiLink 
              component={Link} 
              to="/login"
              sx={{ 
                color: '#1976d2',
                '&:hover': {
                  color: '#1565c0',
                },
              }}
            >
              Войти
            </MuiLink>
          </Typography>
        </Box>
      </form>
    </AuthFormContainer>
  );
};

export default RegisterForm; 