import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  TextField,
  Button,
  Grid,
  CircularProgress,
  Link as MuiLink,
  Typography,
  Box,
} from '@mui/material';
import { authService } from '../../services/api';
import { setCredentials } from '../../store/slices/authSlice';
import AuthFormContainer from './AuthFormContainer';

const LoginForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await authService.login(formData);
      dispatch(setCredentials({
        user: response.user,
        token: response.token,
        role: response.user.role,
      }));
      navigate(response.user.role === 'admin' ? '/admin' : '/user');
    } catch (err) {
      setError(err.response?.data?.message || 'Ошибка при входе');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthFormContainer title="Вход в систему">
      <form onSubmit={handleSubmit}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
            size="medium"
            sx={{ 
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: '#1976d2',
                },
                '&:hover fieldset': {
                  borderColor: '#1565c0',
                },
              },
            }}
          />

          <TextField
            fullWidth
            label="Пароль"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            size="medium"
            sx={{ 
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: '#1976d2',
                },
                '&:hover fieldset': {
                  borderColor: '#1565c0',
                },
              },
            }}
          />

          {error && (
            <Typography color="error" align="center">
              {error}
            </Typography>
          )}

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            disabled={loading}
            size="large"
            sx={{ 
              py: 1.5,
              fontSize: '1.1rem',
              textTransform: 'none',
            }}
          >
            {loading ? <CircularProgress size={24} /> : 'Войти'}
          </Button>

          <Typography align="center" sx={{ mt: 2 }}>
            Нет аккаунта?{' '}
            <MuiLink 
              component={Link} 
              to="/register"
              sx={{ 
                color: '#1976d2',
                '&:hover': {
                  color: '#1565c0',
                },
              }}
            >
              Зарегистрироваться
            </MuiLink>
          </Typography>
        </Box>
      </form>
    </AuthFormContainer>
  );
};

export default LoginForm; 