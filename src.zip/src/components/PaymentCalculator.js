import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { formatCurrency } from '../utils/formatters';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Grid,
  Divider,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText
} from '@mui/material';

const PaymentCalculator = () => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    amount: '',
    term: '',
    interestRate: ''
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCalculate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Локальный расчет без обращения к API
      const amount = parseFloat(formData.amount);
      const term = parseInt(formData.term);
      const interestRate = parseFloat(formData.interestRate);
      
      if (isNaN(amount) || isNaN(term) || isNaN(interestRate)) {
        throw new Error('Неверный формат данных');
      }
      
      // Расчет ежемесячного платежа по формуле аннуитетного платежа
      const monthlyInterestRate = interestRate / 100 / 12;
      const x = Math.pow(1 + monthlyInterestRate, term);
      const monthlyPayment = amount * monthlyInterestRate * x / (x - 1);
      
      // Расчет общей суммы и переплаты
      const totalAmount = monthlyPayment * term;
      const overpayment = totalAmount - amount;
      
      // Формирование графика платежей
      const schedule = [];
      let remainingAmount = amount;
      
      for (let i = 1; i <= term; i++) {
        // Расчет платежа по процентам
        const interestPayment = remainingAmount * monthlyInterestRate;
        // Расчет платежа по основному долгу
        const principalPayment = monthlyPayment - interestPayment;
        // Расчет оставшейся суммы основного долга
        remainingAmount -= principalPayment;
        
        // Формирование объекта платежа
        const payment = {
          paymentNumber: i,
          plannedDate: new Date(Date.now() + i * 30 * 24 * 60 * 60 * 1000),
          amount: monthlyPayment,
          principalPayment,
          interestPayment,
          remainingAmount: remainingAmount > 0 ? remainingAmount : 0
        };
        
        schedule.push(payment);
      }
      
      setResult({
        monthlyPayment,
        totalAmount,
        overpayment,
        schedule
      });
    } catch (err) {
      setError(err.message || 'Ошибка при расчете платежей');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h5" component="h2" gutterBottom>
              Калькулятор платежей
            </Typography>
            
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            
            <form onSubmit={handleCalculate}>
              <TextField
                label="Сумма"
                type="number"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
                inputProps={{ min: 0, step: "0.01" }}
                variant="outlined"
              />
              
              <TextField
                label="Срок (месяцев)"
                type="number"
                name="term"
                value={formData.term}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
                inputProps={{ min: 1 }}
                variant="outlined"
              />
              
              <TextField
                label="Процентная ставка"
                type="number"
                name="interestRate"
                value={formData.interestRate}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
                inputProps={{ min: 0, step: "0.01" }}
                variant="outlined"
              />
              
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
                disabled={loading}
                sx={{ mt: 2 }}
              >
                {loading ? <CircularProgress size={24} /> : 'Рассчитать'}
              </Button>
            </form>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={7}>
          {result && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h5" component="h2" gutterBottom>
                Результаты расчета
              </Typography>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={4}>
                  <Card>
                    <CardContent>
                      <Typography variant="subtitle1" color="text.secondary">
                        Ежемесячный платеж
                      </Typography>
                      <Typography variant="h6">
                        {formatCurrency(result.monthlyPayment)}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                  <Card>
                    <CardContent>
                      <Typography variant="subtitle1" color="text.secondary">
                        Общая сумма
                      </Typography>
                      <Typography variant="h6">
                        {formatCurrency(result.totalAmount)}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                  <Card>
                    <CardContent>
                      <Typography variant="subtitle1" color="text.secondary">
                        Переплата
                      </Typography>
                      <Typography variant="h6">
                        {formatCurrency(result.overpayment)}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
              
              <Typography variant="h6" gutterBottom>
                График платежей
              </Typography>
              
              <Paper variant="outlined" sx={{ maxHeight: 400, overflow: 'auto' }}>
                <List>
                  {result.schedule.map(payment => (
                    <React.Fragment key={payment.paymentNumber}>
                      <ListItem>
                        <Grid container spacing={1}>
                          <Grid item xs={12}>
                            <Typography variant="subtitle1">
                              Платеж #{payment.paymentNumber} - {new Date(payment.plannedDate).toLocaleDateString()}
                            </Typography>
                          </Grid>
                          <Grid item xs={12} sm={6}>
                            <ListItemText 
                              primary="Сумма" 
                              secondary={formatCurrency(payment.amount)} 
                            />
                          </Grid>
                          <Grid item xs={12} sm={6}>
                            <ListItemText 
                              primary="Остаток долга" 
                              secondary={formatCurrency(payment.remainingAmount)} 
                            />
                          </Grid>
                          <Grid item xs={12} sm={6}>
                            <ListItemText 
                              primary="Основной долг" 
                              secondary={formatCurrency(payment.principalPayment)} 
                            />
                          </Grid>
                          <Grid item xs={12} sm={6}>
                            <ListItemText 
                              primary="Проценты" 
                              secondary={formatCurrency(payment.interestPayment)} 
                            />
                          </Grid>
                        </Grid>
                      </ListItem>
                      {payment.paymentNumber < result.schedule.length && <Divider />}
                    </React.Fragment>
                  ))}
                </List>
              </Paper>
            </Paper>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default PaymentCalculator; 