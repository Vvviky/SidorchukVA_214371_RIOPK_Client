import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Chip,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import RefreshIcon from '@mui/icons-material/Refresh';
import { fetchInstallmentPayments, updatePaymentStatus } from '../store/slices/paymentsSlice';
import { fetchInstallmentDetails } from '../store/slices/installmentsSlice';
import { formatCurrency, formatDate } from '../utils/formatters';
import { showNotification } from './Notification';

const PaymentList = () => {
  const { id, installmentId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  // Убедимся, что у нас есть действительный ID рассрочки
  const actualInstallmentId = installmentId || id;
  
  const { user } = useSelector(state => state.auth);
  const { loading: installmentLoading, currentInstallment } = useSelector(state => state.installments);
  const { loading: paymentsLoading, error, installmentPayments } = useSelector(state => state.payments);
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [newStatus, setNewStatus] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  
  const loading = installmentLoading || paymentsLoading || refreshing;
  const payments = installmentPayments[actualInstallmentId] || [];

  useEffect(() => {
    if (actualInstallmentId) {
      console.log(`Загружаем данные рассрочки ID=${actualInstallmentId} и платежи к ней`);
      dispatch(fetchInstallmentDetails(actualInstallmentId));
      loadPayments();
    } else {
      console.error('ID рассрочки не указан');
    }
  }, [dispatch, actualInstallmentId]);

  const loadPayments = async () => {
    try {
      console.log(`Загружаем платежи для рассрочки ID=${actualInstallmentId}`);
      await dispatch(fetchInstallmentPayments(actualInstallmentId)).unwrap();
      console.log('Платежи успешно загружены');
    } catch (err) {
      console.error('Ошибка при загрузке платежей:', err);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await dispatch(fetchInstallmentDetails(actualInstallmentId));
      await dispatch(fetchInstallmentPayments(actualInstallmentId));
    } catch (error) {
      console.error('Ошибка при обновлении данных:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const handleStatusChange = (payment, status) => {
    setSelectedPayment(payment);
    setNewStatus(status);
    setDialogOpen(true);
  };

  const handleConfirmStatusChange = async () => {
    if (selectedPayment && newStatus) {
      await dispatch(updatePaymentStatus({ 
        paymentId: selectedPayment.id, 
        status: newStatus 
      }));
      
      // Обновить данные после изменения
      dispatch(fetchInstallmentPayments(actualInstallmentId));
      dispatch(fetchInstallmentDetails(actualInstallmentId));
    }
    setDialogOpen(false);
  };
  
  const handleCancelStatusChange = () => {
    setDialogOpen(false);
    setSelectedPayment(null);
    setNewStatus('');
  };
  
  const getStatusText = (status) => {
    switch (status) {
      case 'pending':
        return 'Ожидает оплаты';
      case 'paid':
        return 'Оплачен';
      case 'overdue':
        return 'Просрочен';
      case 'cancelled':
        return 'Отменен';
      default:
        return status;
    }
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'warning';
      case 'paid':
        return 'success';
      case 'overdue':
        return 'error';
      case 'cancelled':
        return 'default';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '300px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ mt: 4 }}>
        <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>
        <Button 
          startIcon={<ArrowBackIcon />} 
          onClick={() => navigate(-1)}
          variant="outlined"
        >
          Назад
        </Button>
      </Box>
    );
  }

  console.log('Текущие платежи:', payments);

  return (
    <Box sx={{ mt: 4 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <IconButton 
            onClick={() => navigate(-1)} 
            sx={{ mr: 2 }}
            color="primary"
          >
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h5" component="h1">
            Платежи по рассрочке
            {currentInstallment && `: ${currentInstallment.title || `ID ${currentInstallment.id}`}`}
          </Typography>
        </Box>
        <Button 
          variant="outlined" 
          color="primary" 
          startIcon={<RefreshIcon />}
          onClick={handleRefresh}
          disabled={refreshing}
        >
          Обновить
        </Button>
      </Box>
      
      {currentInstallment && (
        <Paper sx={{ p: 2, mb: 3 }} elevation={1}>
          <Typography variant="h6" gutterBottom>
            Информация о рассрочке
          </Typography>
          <Divider sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3 }}>
            <Box>
              <Typography variant="body2" color="text.secondary">Общая сумма</Typography>
              <Typography variant="body1" fontWeight="bold">{formatCurrency(currentInstallment.totalAmount)}</Typography>
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">Оплачено</Typography>
              <Typography variant="body1" fontWeight="bold">{formatCurrency(currentInstallment.paidAmount || 0)}</Typography>
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">Осталось оплатить</Typography>
              <Typography variant="body1" fontWeight="bold">
                {formatCurrency((currentInstallment.totalAmount - (currentInstallment.paidAmount || 0)).toFixed(2))}
              </Typography>
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">Срок рассрочки</Typography>
              <Typography variant="body1" fontWeight="bold">{currentInstallment.term} мес.</Typography>
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">Статус</Typography>
              <Chip 
                label={getStatusText(currentInstallment.status)} 
                color={getStatusColor(currentInstallment.status)} 
                size="small" 
              />
            </Box>
          </Box>
        </Paper>
      )}
      
      <Paper sx={{ width: '100%', mb: 2 }} elevation={3}>
        {Array.isArray(payments) && payments.length > 0 ? (
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Номер платежа</TableCell>
                  <TableCell>Сумма</TableCell>
                  <TableCell>Дата платежа</TableCell>
                  <TableCell>Статус</TableCell>
                  {user?.isAdmin && <TableCell>Действия</TableCell>}
                </TableRow>
              </TableHead>
              <TableBody>
                {payments.map((payment, index) => (
                  <TableRow key={payment.id || index}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{formatCurrency(payment.amount)}</TableCell>
                    <TableCell>{formatDate(payment.paidAt || payment.dueDate)}</TableCell>
                    <TableCell>
                      <Chip 
                        label={getStatusText(payment.status)} 
                        color={getStatusColor(payment.status)}
                        size="small"
                        icon={payment.status === 'paid' ? <CheckCircleIcon /> : 
                             payment.status === 'overdue' ? <WarningIcon /> : null}
                      />
                    </TableCell>
                    {user?.isAdmin && (
                      <TableCell>
                        {payment.status === 'pending' && (
                          <Box sx={{ display: 'flex', gap: 1 }}>
                            <Button 
                              variant="outlined" 
                              color="success" 
                              size="small"
                              onClick={() => handleStatusChange(payment, 'paid')}
                            >
                              Оплачен
                            </Button>
                            <Button 
                              variant="outlined" 
                              color="error" 
                              size="small"
                              onClick={() => handleStatusChange(payment, 'overdue')}
                            >
                              Просрочен
                            </Button>
                          </Box>
                        )}
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="body1" color="textSecondary">
              По данной рассрочке нет платежей
            </Typography>
            <Button 
              variant="contained" 
              color="primary" 
              sx={{ mt: 2 }}
              onClick={handleRefresh}
            >
              Обновить
            </Button>
          </Box>
        )}
      </Paper>
      
      {/* Диалог подтверждения изменения статуса */}
      <Dialog
        open={dialogOpen}
        onClose={handleCancelStatusChange}
      >
        <DialogTitle>Изменение статуса платежа</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Вы уверены, что хотите изменить статус платежа на "{getStatusText(newStatus)}"?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancelStatusChange} color="primary">
            Отмена
          </Button>
          <Button onClick={handleConfirmStatusChange} color={newStatus === 'paid' ? 'success' : 'error'}>
            Подтвердить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PaymentList; 