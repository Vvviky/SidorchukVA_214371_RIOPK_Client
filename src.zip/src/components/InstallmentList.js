import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Alert,
  Chip,
  Link,
  Tabs,
  Tab,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import AddIcon from '@mui/icons-material/Add';
import { 
  fetchAdminInstallments, 
  fetchUserInstallments, 
  updateInstallmentStatus 
} from '../store/slices/installmentsSlice';

const InstallmentList = ({ isAdmin = false }) => {
  const dispatch = useDispatch();
  const { userInstallments, adminInstallments, loading, error } = useSelector(state => state.installments);
  const { userInfo } = useSelector(state => state.auth);
  
  const [tab, setTab] = useState(0);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedInstallment, setSelectedInstallment] = useState(null);
  
  // Логируем данные для отладки
  console.log('userInstallments:', userInstallments);
  console.log('adminInstallments:', adminInstallments);
  
  // Проверяем, что значение является массивом
  const installments = Array.isArray(isAdmin ? adminInstallments : userInstallments) 
    ? (isAdmin ? adminInstallments : userInstallments) 
    : [];

  useEffect(() => {
    dispatch(isAdmin ? fetchAdminInstallments() : fetchUserInstallments());
  }, [dispatch, isAdmin]);
  
  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };
  
  const handleDeleteClick = (installment) => {
    setSelectedInstallment(installment);
    setDeleteDialogOpen(true);
  };
  
  const handleDeleteConfirm = () => {
    dispatch(updateInstallmentStatus({ 
      id: selectedInstallment.id, 
      status: 'cancelled'
    }))
    .unwrap()
    .then(() => {
      setDeleteDialogOpen(false);
      setSelectedInstallment(null);
      // Перезагрузка списка после обновления статуса
      dispatch(isAdmin ? fetchAdminInstallments() : fetchUserInstallments());
    })
    .catch(error => {
      console.error('Failed to cancel installment:', error);
    });
  };
  
  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setSelectedInstallment(null);
  };
  
  // Функция для проверки статуса, учитывая разные варианты именования
  const checkStatus = (installment, statusValues) => {
    const status = installment.status?.toUpperCase?.() || installment.status;
    return statusValues.some(val => status === val.toUpperCase());
  };
  
  // Фильтрация рассрочек по вкладкам с учетом разных форматов статусов
  const filteredInstallments = tab === 0 
    ? installments 
    : (Array.isArray(installments) 
        ? installments.filter(i => {
            if (tab === 1) {
              return checkStatus(i, ['ACTIVE', 'active']);
            } else {
              return checkStatus(i, ['CLOSED', 'closed', 'completed']);
            }
          }) 
        : []);
  
  // Форматирование даты с проверкой на корректность
  const formatDate = (dateString) => {
    if (!dateString) return '—';
    
    try {
      const date = new Date(dateString);
      
      // Проверка, что дата действительна
      if (isNaN(date.getTime())) {
        return '—';
      }
      
      return new Intl.DateTimeFormat('ru-RU').format(date);
    } catch (error) {
      console.error('Ошибка форматирования даты:', error);
      return '—';
    }
  };
  
  // Получение статуса в удобочитаемом формате
  const getStatusChip = (status) => {
    const statusUpper = status?.toUpperCase?.() || '';
    
    switch(statusUpper) {
      case 'ACTIVE':
        return <Chip label="Активна" color="primary" size="small" />;
      case 'CLOSED':
        return <Chip label="Закрыта" color="success" size="small" />;
      case 'OVERDUE':
        return <Chip label="Просрочена" color="error" size="small" />;
      default:
        return <Chip label={status || 'Неизвестно'} color="default" size="small" />;
    }
  };

  return (
    <Box sx={{ mt: 4 }}>
      {!isAdmin && (
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h5" component="h1">
            Мои рассрочки
          </Typography>
          <Button 
            component={RouterLink} 
            to="/create-installment" 
            variant="contained" 
            color="primary"
            startIcon={<AddIcon />}
          >
            Создать рассрочку
          </Button>
        </Box>
      )}
      
      {isAdmin && (
        <Typography variant="h5" component="h1" sx={{ mb: 2 }}>
          Управление рассрочками
        </Typography>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      {!Array.isArray(isAdmin ? adminInstallments : userInstallments) && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Данные о рассрочках загружены в неверном формате: ожидается массив
        </Alert>
      )}
      
      <Paper sx={{ width: '100%', mb: 2 }} elevation={3}>
        <Tabs 
          value={tab} 
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
        >
          <Tab label="Все" />
          <Tab label="Активные" />
          <Tab label="Закрытые" />
        </Tabs>
        
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        ) : !Array.isArray(filteredInstallments) || filteredInstallments.length === 0 ? (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="body1" color="textSecondary">
              {tab === 0 
                ? "Рассрочек не найдено" 
                : tab === 1 
                  ? "Активных рассрочек не найдено" 
                  : "Закрытых рассрочек не найдено"}
            </Typography>
          </Box>
        ) : (
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Название</TableCell>
                  {isAdmin && <TableCell>Пользователь</TableCell>}
                  <TableCell>Сумма</TableCell>
                  <TableCell>Осталось оплатить</TableCell>
                  <TableCell>Дата создания</TableCell>
                  <TableCell>Статус</TableCell>
                  <TableCell>Действия</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {Array.isArray(filteredInstallments) && filteredInstallments.map((installment) => (
                  <TableRow key={installment.id}>
                    <TableCell>{installment.title}</TableCell>
                    {isAdmin && (
                      <TableCell>
                        {installment.user?.email || 'Неизвестно'}
                      </TableCell>
                    )}
                    <TableCell>{installment.totalAmount} BYN</TableCell>
                    <TableCell>{installment.remainingAmount} BYN</TableCell>
                    <TableCell>{formatDate(installment.createdAt)}</TableCell>
                    <TableCell>{getStatusChip(installment.status)}</TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex' }}>
                        <IconButton
                          component={RouterLink}
                          to={`/installments/${installment.id}`}
                          color="primary"
                          size="small"
                        >
                          <VisibilityIcon />
                        </IconButton>
                        
                        {!isAdmin && checkStatus(installment, ['ACTIVE', 'active']) && (
                          <Button
                            variant="contained"
                            size="small"
                            color="success"
                            component={RouterLink}
                            to={`/installments/${installment.id}/payment`}
                            sx={{ ml: 1 }}
                          >
                            Оплатить
                          </Button>
                        )}
                        
                        {(userInfo?.isAdmin || checkStatus(installment, ['ACTIVE', 'active'])) && (
                          <IconButton
                            color="error"
                            size="small"
                            onClick={() => handleDeleteClick(installment)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        )}
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>
      
      {/* Диалог подтверждения удаления */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
      >
        <DialogTitle>Подтверждение удаления</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Вы уверены, что хотите удалить рассрочку "{selectedInstallment?.title}"?
            Это действие нельзя отменить.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Отмена</Button>
          <Button onClick={handleDeleteConfirm} color="error" autoFocus>
            Удалить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default InstallmentList; 