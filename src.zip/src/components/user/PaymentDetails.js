import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Chip,
  CircularProgress,
  Button,
} from '@mui/material';
import { paymentService } from '../../services/api';

const PaymentDetails = () => {
  const { id } = useParams();
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPayment = async () => {
      try {
        const data = await paymentService.getPaymentById(id);
        setPayment(data);
      } catch (err) {
        setError('Ошибка при загрузке данных платежа');
      } finally {
        setLoading(false);
      }
    };

    fetchPayment();
  }, [id]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'warning';
      case 'confirmed':
        return 'success';
      case 'failed':
        return 'error';
      default:
        return 'default';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending':
        return 'Ожидает подтверждения';
      case 'confirmed':
        return 'Подтвержден';
      case 'failed':
        return 'Ошибка';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Paper sx={{ p: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="h5" gutterBottom>
              Детали платежа #{payment.id}
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle1" color="textSecondary">
              Сумма
            </Typography>
            <Typography variant="h6">
              {payment.amount} BYN
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle1" color="textSecondary">
              Статус
            </Typography>
            <Chip
              label={getStatusText(payment.status)}
              color={getStatusColor(payment.status)}
              sx={{ mt: 1 }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle1" color="textSecondary">
              Дата создания
            </Typography>
            <Typography>
              {new Date(payment.createdAt).toLocaleString()}
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle1" color="textSecondary">
              Дата обновления
            </Typography>
            <Typography>
              {new Date(payment.updatedAt).toLocaleString()}
            </Typography>
          </Grid>

          {payment.description && (
            <Grid item xs={12}>
              <Typography variant="subtitle1" color="textSecondary">
                Описание
              </Typography>
              <Typography>
                {payment.description}
              </Typography>
            </Grid>
          )}

          {payment.status === 'failed' && (
            <Grid item xs={12}>
              <Button
                variant="contained"
                color="primary"
                onClick={() => window.location.reload()}
              >
                Повторить оплату
              </Button>
            </Grid>
          )}
        </Grid>
      </Paper>
    </Box>
  );
};

export default PaymentDetails; 