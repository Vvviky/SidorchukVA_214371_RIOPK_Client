import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Card,
  CardContent,
  CardActions,
  Button,
  Grid,
  Chip,
  CircularProgress,
  Alert,
  Container,
  Divider,
  Paper
} from '@mui/material';
import { 
  fetchInstallmentTemplates, 
  createInstallmentFromTemplate 
} from '../../store/slices/installmentsSlice';

const TemplateSelection = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { templates, templatesLoading, templatesError, loading, error } = useSelector(state => state.installments);
  const { user } = useSelector(state => state.auth);
  
  // Состояние для отслеживания, какой шаблон в процессе создания
  const [loadingTemplateId, setLoadingTemplateId] = useState(null);
  const [localError, setLocalError] = useState(null);
  
  useEffect(() => {
    dispatch(fetchInstallmentTemplates());
  }, [dispatch]);
  
  const handleCreateFromTemplate = async (templateId) => {
    setLoadingTemplateId(templateId);
    setLocalError(null);
    
    // Проверяем, авторизован ли пользователь
    if (!user || !user.id) {
      setLocalError('Для создания рассрочки необходимо авторизоваться');
      setLoadingTemplateId(null);
      return;
    }
    
    try {
      const resultAction = await dispatch(createInstallmentFromTemplate(templateId));
      
      if (createInstallmentFromTemplate.fulfilled.match(resultAction)) {
        // Успешное создание рассрочки
        navigate('/installments');
      } else if (createInstallmentFromTemplate.rejected.match(resultAction)) {
        // Ошибка уже будет в Redux, ничего делать не надо
        console.error('Ошибка при создании рассрочки из шаблона:', resultAction.error);
        setLocalError(resultAction.payload || 'Не удалось создать рассрочку из шаблона');
      }
    } catch (error) {
      console.error('Непредвиденная ошибка:', error);
      setLocalError('Произошла непредвиденная ошибка при создании рассрочки');
    } finally {
      setLoadingTemplateId(null);
    }
  };
  
  if (templatesLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  // Убедимся, что templates – это массив
  const templatesArray = Array.isArray(templates) ? templates : [];

  return (
    <Container maxWidth="lg">
      <Paper sx={{ p: 3, mt: 3 }}>
        <Typography variant="h4" gutterBottom>
          Выберите шаблон рассрочки
        </Typography>
        
        <Typography variant="body1" color="text.secondary" paragraph>
          Вы можете создать рассрочку на основе одного из предустановленных шаблонов
        </Typography>
        
        {templatesError && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {templatesError}
          </Alert>
        )}
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        {localError && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {localError}
          </Alert>
        )}
        
        {templatesArray.length === 0 ? (
          <Alert severity="info">
            В настоящее время нет доступных шаблонов рассрочек
          </Alert>
        ) : (
          <Grid container spacing={3} sx={{ mt: 2 }}>
            {templatesArray.map((template) => (
              <Grid item xs={12} sm={6} md={4} key={template.id}>
                <Card 
                  elevation={3}
                  sx={{ 
                    height: '100%', 
                    display: 'flex', 
                    flexDirection: 'column',
                    transition: 'transform 0.2s',
                    '&:hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: 6
                    }
                  }}
                >
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography variant="h5" component="div" gutterBottom>
                      {template.name}
                    </Typography>
                    
                    <Chip 
                      label={template.category} 
                      size="small" 
                      color="primary" 
                      sx={{ mb: 2 }}
                    />
                    
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {template.description || 'Нет описания'}
                    </Typography>
                    
                    <Divider sx={{ my: 1.5 }} />
                    
                    <Typography variant="body2">
                      <strong>Сумма:</strong> {template.minAmount} - {template.maxAmount} {template.currency}
                    </Typography>
                    
                    <Typography variant="body2">
                      <strong>Срок:</strong> {template.availableTerms.join(', ')} мес.
                    </Typography>
                    
                    <Typography variant="body2">
                      <strong>Ставка:</strong> {template.interestRate}%
                    </Typography>
                    
                    {template.requiresApproval && (
                      <Typography variant="body2" color="warning.main" sx={{ mt: 1 }}>
                        Требует одобрения администратора
                      </Typography>
                    )}
                  </CardContent>
                  <CardActions>
                    <Button 
                      fullWidth
                      variant="contained" 
                      onClick={() => handleCreateFromTemplate(template.id)}
                      disabled={loading || loadingTemplateId === template.id}
                    >
                      {loadingTemplateId === template.id ? (
                        <CircularProgress size={24} />
                      ) : (
                        'Создать рассрочку'
                      )}
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Paper>
    </Container>
  );
};

export default TemplateSelection; 