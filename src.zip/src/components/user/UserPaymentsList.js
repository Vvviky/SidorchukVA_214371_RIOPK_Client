import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { 
  fetchPaymentsByInstallmentId, 
  createPayment,
  selectPaymentsLoading,
  selectPaymentsError,
  selectPaymentsList
} from '../../store/slices/paymentsSlice';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Button,
  Typography,
  Box,
  CircularProgress,
  Alert
} from '@mui/material';
import { formatCurrency, formatDate, formatStatus } from '../../utils/formatters';
import Loader from '../Loader';

const UserPaymentsList = () => {
  const { installmentId } = useParams();
  const dispatch = useDispatch();
  const payments = useSelector(selectPaymentsList);
  const loading = useSelector(selectPaymentsLoading);
  const error = useSelector(selectPaymentsError);
  const [paymentError, setPaymentError] = useState(null);

  useEffect(() => {
    if (installmentId) {
      dispatch(fetchPaymentsByInstallmentId(installmentId));
    }
  }, [dispatch, installmentId]);

  const handlePayment = async (paymentId) => {
    setPaymentError(null);
    try {
      await dispatch(createPayment({ paymentId })).unwrap();
      dispatch(fetchPaymentsByInstallmentId(installmentId));
    } catch (err) {
      setPaymentError(err.message || 'Ошибка при создании платежа');
    }
  };

  if (loading) {
    return <Loader />;
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  if (!payments || payments.length === 0) {
    return <Typography variant="h6">Платежи не найдены</Typography>;
  }

  // Получаем информацию об рассрочке из первого платежа
  const installmentInfo = payments[0]?.installment || {};

  return (
    <Box sx={{ mt: 3 }}>
      <Typography variant="h5" gutterBottom>
        График платежей
      </Typography>
      
      <Box sx={{ mb: 3 }}>
        <Typography variant="subtitle1">
          Сумма рассрочки: {formatCurrency(installmentInfo.totalAmount)}
        </Typography>
        <Typography variant="subtitle1">
          Количество платежей: {payments.length}
        </Typography>
        <Typography variant="subtitle1">
          Статус: {formatStatus(installmentInfo.status)}
        </Typography>
      </Box>
      
      {paymentError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {paymentError}
        </Alert>
      )}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Дата платежа</TableCell>
              <TableCell>Сумма</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {payments.map((payment) => (
              <TableRow key={payment._id}>
                <TableCell>{formatDate(payment.dueDate)}</TableCell>
                <TableCell>{formatCurrency(payment.amount)}</TableCell>
                <TableCell>{formatStatus(payment.status)}</TableCell>
                <TableCell>
                  {payment.status === 'pending' && (
                    <Button 
                      variant="contained" 
                      color="primary" 
                      onClick={() => handlePayment(payment._id)}
                      disabled={loading}
                    >
                      {loading ? <CircularProgress size={24} /> : 'Оплатить'}
                    </Button>
                  )}
                  {payment.status === 'paid' && (
                    <Typography variant="body2" color="primary">
                      Оплачено {formatDate(payment.paymentDate)}
                    </Typography>
                  )}
                  {payment.status === 'overdue' && (
                    <Button 
                      variant="contained" 
                      color="error" 
                      onClick={() => handlePayment(payment._id)}
                      disabled={loading}
                    >
                      Оплатить просроченный
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default UserPaymentsList; 