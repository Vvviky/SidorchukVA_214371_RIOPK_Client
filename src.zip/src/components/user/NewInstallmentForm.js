import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Slider,
  Grid,
} from '@mui/material';
import { setInstallments } from '../../store/slices/installmentsSlice';

const NewInstallmentForm = () => {
  const [formData, setFormData] = useState({
    amount: 10000,
    term: 6,
  });
  const [error, setError] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleAmountChange = (event) => {
    setFormData({
      ...formData,
      amount: event.target.value,
    });
  };

  const handleTermChange = (event, newValue) => {
    setFormData({
      ...formData,
      term: newValue,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Имитация создания новой рассрочки
      const newInstallment = {
        id: Date.now(),
        amount: formData.amount,
        term: formData.term,
        status: 'pending',
        createdAt: new Date().toISOString().split('T')[0],
      };

      // Здесь будет реальный API-запрос
      // Для демонстрации используем имитацию
      dispatch(setInstallments([newInstallment]));
      navigate('/user/installments');
    } catch (err) {
      setError('Ошибка при создании рассрочки. Попробуйте позже.');
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
      }}
    >
      <Paper elevation={3} sx={{ p: 4, width: 600 }}>
        <Typography variant="h5" component="h1" gutterBottom align="center">
          Оформление рассрочки
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Сумма рассрочки"
                type="number"
                value={formData.amount}
                onChange={handleAmountChange}
                inputProps={{ min: 10000, max: 1000000 }}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Typography gutterBottom>Срок рассрочки (месяцев)</Typography>
              <Slider
                value={formData.term}
                onChange={handleTermChange}
                min={3}
                max={36}
                step={1}
                marks
                valueLabelDisplay="auto"
              />
            </Grid>
            {error && (
              <Grid item xs={12}>
                <Typography color="error">{error}</Typography>
              </Grid>
            )}
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                fullWidth
                size="large"
              >
                Оформить рассрочку
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Box>
  );
};

export default NewInstallmentForm; 