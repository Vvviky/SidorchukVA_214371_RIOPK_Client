import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  CircularProgress,
  Alert
} from '@mui/material';
import { fetchUserInstallments } from '../../store/slices/installmentsSlice';
import { formatCurrency, formatDate } from '../../utils/formatters';

const UserInstallmentsList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { userInstallments, loading, error } = useSelector(state => state.installments);
  const { isAuthenticated } = useSelector(state => state.auth);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    // Однократная загрузка списка рассрочек при монтировании компонента
    dispatch(fetchUserInstallments());
    
  }, [dispatch, isAuthenticated, navigate]);

  // Добавим логирование для отладки
  useEffect(() => {
    console.log("Текущий список рассрочек:", userInstallments);
  }, [userInstallments]);

  const getStatusText = (status) => {
    switch (status) {
      case 'pending':
        return 'На рассмотрении';
      case 'approved':
      case 'active': // Добавим активный статус
        return 'Одобрена/Активна';
      case 'rejected':
        return 'Отклонена';
      case 'completed':
        return 'Завершена';
      case 'cancelled':
        return 'Отменена';
      default:
        return status;
    }
  };

  const handleCreateInstallment = () => {
    navigate('/create');
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" gutterBottom>
          Мои рассрочки
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            color="primary" 
            onClick={() => dispatch(fetchUserInstallments())}
            sx={{ mr: 2 }}
          >
            Обновить
          </Button>
          <Button 
            variant="contained" 
            color="primary" 
            onClick={handleCreateInstallment}
          >
            Создать рассрочку
          </Button>
        </Box>
      </Box>
      
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Название</TableCell>
              <TableCell>Сумма</TableCell>
              <TableCell>Оплачено</TableCell>
              <TableCell>Осталось</TableCell>
              <TableCell>Срок (мес.)</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Дата создания</TableCell>
              <TableCell>Действия</TableCell> 
            </TableRow>
          </TableHead>
          <TableBody>
            {userInstallments && Array.isArray(userInstallments) && userInstallments.length > 0 ? (
              userInstallments.map((installment) => (
                <TableRow key={installment.id}>
                  <TableCell>{installment.title || installment.id}</TableCell>
                  <TableCell>{formatCurrency(installment.totalAmount)}</TableCell>
                  <TableCell>{formatCurrency(installment.paidAmount || 0)}</TableCell>
                  <TableCell>
                    {formatCurrency((installment.totalAmount - (installment.paidAmount || 0)).toFixed(2))}
                  </TableCell>
                  <TableCell>{installment.term}</TableCell>
                  <TableCell>{getStatusText(installment.status)}</TableCell>
                  <TableCell>{formatDate(installment.createdAt)}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', mt: 1 }}>
                      <Button
                        variant="contained"
                        size="small"
                        color="primary"
                        component={Link}
                        to={`/installments/${installment.id}`}
                        sx={{ mr: 1 }}
                      >
                        Подробнее
                      </Button>
                      <Button
                        variant="contained"
                        size="small"
                        color="primary"
                        component={Link}
                        to={`/installments/${installment.id}/payments`}
                        sx={{ mr: 1 }}
                      >
                        Платежи
                      </Button>
                      {installment.status === 'active' && (
                        <Button
                          variant="contained"
                          size="small"
                          color="success"
                          component={Link}
                          to={`/installments/${installment.id}/payment`}
                        >
                          Оплатить
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  {loading ? 'Загрузка данных...' : 'У вас пока нет рассрочек.'}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default UserInstallmentsList; 