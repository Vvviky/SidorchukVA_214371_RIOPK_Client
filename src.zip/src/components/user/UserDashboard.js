import React, { useEffect, useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Container,
  Typography,
  Paper,
  Grid,
  Button,
  Card,
  CardContent,
  Divider,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Chip,
  Alert,
  CircularProgress
} from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import MoneyIcon from '@mui/icons-material/Money';
import PaymentIcon from '@mui/icons-material/Payment';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ViewListIcon from '@mui/icons-material/ViewList';
import ListAltIcon from '@mui/icons-material/ListAlt';
import { fetchUserInstallments } from '../../store/slices/installmentsSlice';
import Loader from '../Loader';
import { formatCurrency, formatDate, formatStatus } from '../../utils/formatters';

const UserDashboard = () => {
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.auth);
  const { userInstallments, loading, error } = useSelector((state) => state.installments);
  
  useEffect(() => {
    dispatch(fetchUserInstallments());
  }, [dispatch]);
  
  // Вычисляемые данные на основе загруженных рассрочек
  const dashboardData = useMemo(() => {
    // Убедимся, что userInstallments - это массив
    const installments = Array.isArray(userInstallments) ? userInstallments : [];
    
    // Выводим в консоль для отладки
    console.log('userInstallments:', userInstallments);
    
    const activeInstallments = installments.filter(inst => inst.status === 'ACTIVE' || inst.status === 'active' || inst.status === 'approved');
    const completedInstallments = installments.filter(inst => inst.status === 'CLOSED' || inst.status === 'completed');
    const overdueInstallments = installments.filter(inst => inst.status === 'OVERDUE' || inst.status === 'overdue');
    
    const totalActiveAmount = activeInstallments.reduce((sum, inst) => sum + ((inst.totalAmount - (inst.paidAmount || 0)) || 0), 0);
    const totalOverdueAmount = overdueInstallments.reduce((sum, inst) => sum + ((inst.totalAmount - (inst.paidAmount || 0)) || 0), 0);
    
    // Находим следующий платеж
    let nextPayment = null;
    let nextPaymentDate = null;
    
    activeInstallments.forEach(installment => {
      if (installment.nextPaymentDate && (!nextPaymentDate || new Date(installment.nextPaymentDate) < new Date(nextPaymentDate))) {
        nextPaymentDate = installment.nextPaymentDate;
        nextPayment = {
          installmentId: installment.id,
          installmentTitle: installment.title,
          amount: installment.nextPaymentAmount || 0,
          date: installment.nextPaymentDate
        };
      }
    });
    
    return {
      totalInstallments: installments.length,
      activeInstallments: activeInstallments.length,
      completedInstallments: completedInstallments.length,
      overdueInstallments: overdueInstallments.length,
      totalActiveAmount,
      totalOverdueAmount,
      nextPayment
    };
  }, [userInstallments]);
  
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 5 }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }
  
  // Убедимся, что userInstallments - это массив
  const installments = Array.isArray(userInstallments) ? userInstallments : [];
  
  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <Grid container spacing={3}>
        {/* Информация о пользователе */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 2 }}>
              <Avatar sx={{ width: 80, height: 80, mb: 2, bgcolor: 'primary.main' }}>
                <PersonIcon fontSize="large" />
              </Avatar>
              <Typography variant="h5" component="h2" gutterBottom>
                {userInfo?.name || 'Пользователь'}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                {userInfo?.email}
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Box>
              
              <Typography variant="body1" sx={{ mt: 1 }}>
                <strong>Роль:</strong> {userInfo?.isAdmin ? 'Администратор' : 'Пользователь'}
              </Typography>
            </Box>
          </Paper>
        </Grid>
        
        {/* Статистика по рассрочкам */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Статистика
            </Typography>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} sm={4}>
                <Card sx={{ bgcolor: 'info.light', color: 'info.contrastText' }}>
                  <CardContent>
                    <MoneyIcon />
                    <Typography variant="h5" component="div">
                      {dashboardData.totalInstallments}
                    </Typography>
                    <Typography variant="body2">
                      Всего рассрочек
                    </Typography>
                    <Typography variant="h6" component="div" sx={{ mt: 1 }}>
                      {formatCurrency(dashboardData.totalActiveAmount)}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={4}>
                <Card sx={{ bgcolor: 'success.light', color: 'success.contrastText' }}>
                  <CardContent>
                    <AssignmentTurnedInIcon />
                    <Typography variant="h5" component="div">
                      {dashboardData.completedInstallments}
                    </Typography>
                    <Typography variant="body2">
                      Завершенные рассрочки
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={4}>
                <Card sx={{ bgcolor: 'error.light', color: 'error.contrastText' }}>
                  <CardContent>
                    <AssignmentLateIcon />
                    <Typography variant="h5" component="div">
                      {dashboardData.overdueInstallments}
                    </Typography>
                    <Typography variant="body2">
                      Просроченные рассрочки
                    </Typography>
                    <Typography variant="h6" component="div" sx={{ mt: 1 }}>
                      {formatCurrency(dashboardData.totalOverdueAmount)}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
        
        {/* Следующий платеж */}
        {/* <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Ближайший платеж
            </Typography>
            {dashboardData.nextPayment ? (
              <Box sx={{ mt: 2 }}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item>
                    <Avatar sx={{ bgcolor: 'primary.main' }}>
                      <PaymentIcon />
                    </Avatar>
                  </Grid>
                  <Grid item xs>
                    <Typography variant="body1">
                      <strong>{dashboardData.nextPayment.installmentTitle}</strong>
                    </Typography>
                    <Typography variant="h5" color="primary">
                      {formatCurrency(dashboardData.nextPayment.amount)}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                      <CalendarTodayIcon sx={{ mr: 1, fontSize: 'small', color: 'text.secondary' }} />
                      <Typography variant="body2" color="text.secondary">
                        Оплатить до: {formatDate(dashboardData.nextPayment.date)}
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item>
                    <Button 
                      variant="contained" 
                      component={RouterLink} 
                      to={`/installments/${dashboardData.nextPayment.installmentId}`}
                    >
                      Детали
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            ) : (
              <Typography variant="body1" sx={{ mt: 2, fontStyle: 'italic' }}>
                Нет предстоящих платежей
              </Typography>
            )}
          </Paper>
        </Grid> */}
        
        {/* Быстрые действия */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Быстрые действия
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
              <Button
                variant="contained"
                startIcon={<AddCircleIcon />}
                component={RouterLink}
                to="/create-installment"
                fullWidth
                sx={{ mb: 2 }}
              >
                Создать рассрочку
              </Button>
              
              <Button
                variant="outlined"
                startIcon={<ListAltIcon />}
                component={RouterLink}
                to="/templates"
                fullWidth
              >
                Шаблоны рассрочек
              </Button>
              
              <Button
                variant="outlined"
                startIcon={<MoneyIcon />}
                component={RouterLink}
                to="/installments"
                fullWidth
              >
                Мои рассрочки
              </Button>
            </Box>
          </Paper>
        </Grid>
        
        {/* Список последних рассрочек */}
        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6" component="h2">
                Мои рассрочки
              </Typography>
              <Button
                variant="text"
                component={RouterLink}
                to="/installments"
                size="small"
              >
                Показать все
              </Button>
            </Box>
            
            {/* Для отладки - выводим данные о рассрочках */}
            {!Array.isArray(userInstallments) && (
              <Alert severity="warning" sx={{ mb: 2 }}>
                Ошибка данных: userInstallments не является массивом
              </Alert>
            )}
            
            {installments.length > 0 ? (
              <List sx={{ width: '100%' }}>
                {installments.slice(0, 5).map((installment) => (
                  <React.Fragment key={installment.id}>
                    <ListItem alignItems="flex-start">
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: installment.status === 'ACTIVE' || installment.status === 'active' ? 'info.main' : 
                                        installment.status === 'CLOSED' || installment.status === 'completed' ? 'success.main' : 'error.main' }}>
                          {installment.status === 'ACTIVE' || installment.status === 'active' ? <MoneyIcon /> : 
                           installment.status === 'CLOSED' || installment.status === 'completed' ? <AssignmentTurnedInIcon /> : <AssignmentLateIcon />}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography variant="subtitle1">
                              {installment.title}
                            </Typography>
                            <Chip 
                              label={formatStatus(installment.status)} 
                              size="small"
                              color={installment.status === 'ACTIVE' || installment.status === 'active' ? 'info' : 
                                    installment.status === 'CLOSED' || installment.status === 'completed' ? 'success' : 'error'}
                            />
                          </Box>
                        }
                        secondary={
                          <>
                            <Typography component="span" variant="body2" color="text.primary">
                              {formatCurrency(installment.totalAmount)} • 
                            </Typography>
                            {" Осталось: "}
                            <Typography component="span" variant="body2" color="text.primary">
                              {formatCurrency((installment.totalAmount - (installment.paidAmount || 0)).toFixed(2))}
                            </Typography>
                            <br />
                            <Typography component="span" variant="body2" color="text.secondary">
                              Дата создания: {formatDate(installment.createdAt)}
                            </Typography>
                          </>
                        }
                      />
                      <Button
                        variant="outlined"
                        size="small"
                        component={RouterLink}
                        to={`/installments/${installment.id}`}
                        sx={{ alignSelf: 'center', ml: 2 }}
                      >
                        Детали
                      </Button>
                    </ListItem>
                    <Divider variant="inset" component="li" />
                  </React.Fragment>
                ))}
              </List>
            ) : (
              <Typography variant="body1" sx={{ fontStyle: 'italic', textAlign: 'center', py: 3 }}>
                У вас пока нет рассрочек. Создайте свою первую рассрочку.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default UserDashboard; 