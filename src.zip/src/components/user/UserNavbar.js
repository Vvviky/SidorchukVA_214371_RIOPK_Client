import React from 'react';
import { Link } from 'react-router-dom';
import { ListItemIcon, ListItemText, MenuItem } from '@mui/material';
import PaymentIcon from '@mui/icons-material/Payment';
import AddIcon from '@mui/icons-material/Add';

const UserNavbar = () => {
  return (
    <div>
      <MenuItem component={Link} to="/user/payments">
        <ListItemIcon>
          <PaymentIcon />
        </ListItemIcon>
        <ListItemText primary="Мои платежи" />
      </MenuItem>
      <MenuItem component={Link} to="/user/payments/new">
        <ListItemIcon>
          <AddIcon />
        </ListItemIcon>
        <ListItemText primary="Создать платеж" />
      </MenuItem>
    </div>
  );
};

export default UserNavbar; 