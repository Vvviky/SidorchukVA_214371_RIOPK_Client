import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Login from '../Login';

jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn()
}));

jest.mock('../../contexts/AuthContext');

describe('Login', () => {
  const mockNavigate = jest.fn();
  const mockLogin = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    useNavigate.mockReturnValue(mockNavigate);
    useAuth.mockReturnValue({ login: mockLogin });
  });

  it('should render login form', () => {
    render(<Login />);

    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Пароль')).toBeInTheDocument();
    expect(screen.getByText('Войти')).toBeInTheDocument();
    expect(screen.getByText('Регистрация')).toBeInTheDocument();
  });

  it('should handle successful login', async () => {
    mockLogin.mockResolvedValue({});
    render(<Login />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Войти'));

    await waitFor(() => {
      expect(mockLogin).toHaveBeenCalledWith('test@example.com', 'password123');
      expect(mockNavigate).toHaveBeenCalledWith('/');
    });
  });

  it('should handle login error', async () => {
    mockLogin.mockRejectedValue(new Error('Invalid credentials'));
    render(<Login />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Войти'));

    await waitFor(() => {
      expect(screen.getByText('Ошибка при входе')).toBeInTheDocument();
    });
  });

  it('should validate form fields', async () => {
    render(<Login />);

    fireEvent.click(screen.getByText('Войти'));

    expect(screen.getByText('Email обязателен')).toBeInTheDocument();
    expect(screen.getByText('Пароль обязателен')).toBeInTheDocument();
  });

  it('should validate email format', async () => {
    render(<Login />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'invalid-email' } });
    fireEvent.click(screen.getByText('Войти'));

    expect(screen.getByText('Неверный формат email')).toBeInTheDocument();
  });

  it('should navigate to registration page', () => {
    render(<Login />);

    fireEvent.click(screen.getByText('Регистрация'));

    expect(mockNavigate).toHaveBeenCalledWith('/register');
  });

  it('should handle loading state', async () => {
    mockLogin.mockImplementation(() => new Promise(() => {}));
    render(<Login />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Войти'));

    expect(screen.getByText('Загрузка...')).toBeInTheDocument();
  });
}); 