import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Navbar from '../Navbar';

jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn()
}));

jest.mock('../../contexts/AuthContext');

describe('Navbar', () => {
  const mockNavigate = jest.fn();
  const mockLogout = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    useNavigate.mockReturnValue(mockNavigate);
  });

  it('should render navigation for unauthenticated user', () => {
    useAuth.mockReturnValue({ user: null });
    render(<Navbar />);

    expect(screen.getByText('Войти')).toBeInTheDocument();
    expect(screen.getByText('Регистрация')).toBeInTheDocument();
    expect(screen.queryByText('Мои рассрочки')).not.toBeInTheDocument();
    expect(screen.queryByText('Создать рассрочку')).not.toBeInTheDocument();
    expect(screen.queryByText('Калькулятор')).not.toBeInTheDocument();
  });

  it('should render navigation for regular user', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'user' },
      logout: mockLogout
    });
    render(<Navbar />);

    expect(screen.getByText('Мои рассрочки')).toBeInTheDocument();
    expect(screen.getByText('Создать рассрочку')).toBeInTheDocument();
    expect(screen.getByText('Калькулятор')).toBeInTheDocument();
    expect(screen.getByText('Выйти')).toBeInTheDocument();
    expect(screen.queryByText('Войти')).not.toBeInTheDocument();
    expect(screen.queryByText('Регистрация')).not.toBeInTheDocument();
  });

  it('should render navigation for admin user', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'admin' },
      logout: mockLogout
    });
    render(<Navbar />);

    expect(screen.getByText('Мои рассрочки')).toBeInTheDocument();
    expect(screen.getByText('Создать рассрочку')).toBeInTheDocument();
    expect(screen.getByText('Калькулятор')).toBeInTheDocument();
    expect(screen.getByText('Выйти')).toBeInTheDocument();
    expect(screen.queryByText('Войти')).not.toBeInTheDocument();
    expect(screen.queryByText('Регистрация')).not.toBeInTheDocument();
  });

  it('should handle logout', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'user' },
      logout: mockLogout
    });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Выйти'));

    expect(mockLogout).toHaveBeenCalled();
    expect(mockNavigate).toHaveBeenCalledWith('/login');
  });

  it('should navigate to login page', () => {
    useAuth.mockReturnValue({ user: null });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Войти'));

    expect(mockNavigate).toHaveBeenCalledWith('/login');
  });

  it('should navigate to register page', () => {
    useAuth.mockReturnValue({ user: null });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Регистрация'));

    expect(mockNavigate).toHaveBeenCalledWith('/register');
  });

  it('should navigate to installments page', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'user' },
      logout: mockLogout
    });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Мои рассрочки'));

    expect(mockNavigate).toHaveBeenCalledWith('/');
  });

  it('should navigate to create installment page', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'user' },
      logout: mockLogout
    });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Создать рассрочку'));

    expect(mockNavigate).toHaveBeenCalledWith('/create');
  });

  it('should navigate to calculator page', () => {
    useAuth.mockReturnValue({ 
      user: { role: 'user' },
      logout: mockLogout
    });
    render(<Navbar />);

    fireEvent.click(screen.getByText('Калькулятор'));

    expect(mockNavigate).toHaveBeenCalledWith('/calculator');
  });
}); 