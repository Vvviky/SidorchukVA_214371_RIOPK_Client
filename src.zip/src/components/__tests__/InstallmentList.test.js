import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import InstallmentList from '../InstallmentList';
import { installmentService } from '../../services/installment.service';
import { useAuth } from '../../contexts/AuthContext';

jest.mock('../../services/installment.service', () => ({
  installmentService: {
    getInstallments: jest.fn(),
    approveInstallment: jest.fn(),
    rejectInstallment: jest.fn()
  }
}));

jest.mock('../../contexts/AuthContext', () => ({
  useAuth: jest.fn()
}));

describe('InstallmentList', () => {
  const mockGetInstallments = jest.fn();
  const mockApproveInstallment = jest.fn();
  const mockRejectInstallment = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    installmentService.getInstallments = mockGetInstallments;
    installmentService.approveInstallment = mockApproveInstallment;
    installmentService.rejectInstallment = mockRejectInstallment;
    useAuth.mockReturnValue({
      user: { role: 'user' }
    });
  });

  it('should render loading state', () => {
    mockGetInstallments.mockImplementation(() => new Promise(() => {}));
    render(<InstallmentList />);
    expect(screen.getByText('Загрузка...')).toBeInTheDocument();
  });

  it('should render empty state', async () => {
    mockGetInstallments.mockResolvedValue([]);
    render(<InstallmentList />);
    await waitFor(() => {
      expect(screen.getByText('Нет доступных рассрочек')).toBeInTheDocument();
    });
  });

  it('should render installments list', async () => {
    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка 1',
        description: 'Описание тестовой рассрочки 1',
        totalAmount: 10000,
        term: 12,
        status: 'pending',
        createdAt: '2024-01-01T00:00:00.000Z'
      },
      {
        id: 2,
        title: 'Тестовая рассрочка 2',
        description: 'Описание тестовой рассрочки 2',
        totalAmount: 20000,
        term: 24,
        status: 'approved',
        createdAt: '2024-01-02T00:00:00.000Z'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    render(<InstallmentList />);

    await waitFor(() => {
      expect(screen.getByText('Тестовая рассрочка 1')).toBeInTheDocument();
      expect(screen.getByText('Тестовая рассрочка 2')).toBeInTheDocument();
      expect(screen.getByText('10 000 BYN')).toBeInTheDocument();
      expect(screen.getByText('20 000 BYN')).toBeInTheDocument();
      expect(screen.getByText('12 месяцев')).toBeInTheDocument();
      expect(screen.getByText('24 месяца')).toBeInTheDocument();
    });
  });

  it('should show error message when fetch fails', async () => {
    mockGetInstallments.mockRejectedValue(new Error('Ошибка загрузки рассрочек'));
    render(<InstallmentList />);

    await waitFor(() => {
      expect(screen.getByText('Ошибка загрузки рассрочек')).toBeInTheDocument();
    });
  });

  it('should show admin actions for admin user', async () => {
    useAuth.mockReturnValue({
      user: { role: 'admin' }
    });

    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка',
        status: 'pending'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    render(<InstallmentList />);

    await waitFor(() => {
      expect(screen.getByText('Одобрить')).toBeInTheDocument();
      expect(screen.getByText('Отклонить')).toBeInTheDocument();
    });
  });

  it('should handle approve action', async () => {
    useAuth.mockReturnValue({
      user: { role: 'admin' }
    });

    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка',
        status: 'pending'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    mockApproveInstallment.mockResolvedValue({});

    render(<InstallmentList />);

    await waitFor(() => {
      fireEvent.click(screen.getByText('Одобрить'));
    });

    expect(mockApproveInstallment).toHaveBeenCalledWith(1);
    expect(mockGetInstallments).toHaveBeenCalledTimes(2);
  });

  it('should handle reject action', async () => {
    useAuth.mockReturnValue({
      user: { role: 'admin' }
    });

    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка',
        status: 'pending'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    mockRejectInstallment.mockResolvedValue({});

    render(<InstallmentList />);

    await waitFor(() => {
      fireEvent.click(screen.getByText('Отклонить'));
    });

    expect(mockRejectInstallment).toHaveBeenCalledWith(1);
    expect(mockGetInstallments).toHaveBeenCalledTimes(2);
  });

  it('should show error message when approve fails', async () => {
    useAuth.mockReturnValue({
      user: { role: 'admin' }
    });

    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка',
        status: 'pending'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    mockApproveInstallment.mockRejectedValue(new Error('Ошибка одобрения'));

    render(<InstallmentList />);

    await waitFor(() => {
      fireEvent.click(screen.getByText('Одобрить'));
    });

    expect(screen.getByText('Ошибка одобрения')).toBeInTheDocument();
  });

  it('should show error message when reject fails', async () => {
    useAuth.mockReturnValue({
      user: { role: 'admin' }
    });

    const mockInstallments = [
      {
        id: 1,
        title: 'Тестовая рассрочка',
        status: 'pending'
      }
    ];

    mockGetInstallments.mockResolvedValue(mockInstallments);
    mockRejectInstallment.mockRejectedValue(new Error('Ошибка отклонения'));

    render(<InstallmentList />);

    await waitFor(() => {
      fireEvent.click(screen.getByText('Отклонить'));
    });

    expect(screen.getByText('Ошибка отклонения')).toBeInTheDocument();
  });
}); 