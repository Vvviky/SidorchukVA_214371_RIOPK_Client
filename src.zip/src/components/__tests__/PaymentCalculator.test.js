import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { calculationService } from '../../services/calculation.service';
import PaymentCalculator from '../PaymentCalculator';

jest.mock('../../services/calculation.service');

describe('PaymentCalculator', () => {
  const mockCalculatePaymentSchedule = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    calculationService.calculatePaymentSchedule = mockCalculatePaymentSchedule;
  });

  it('should render calculator form', () => {
    render(<PaymentCalculator />);

    expect(screen.getByLabelText('Сумма кредита')).toBeInTheDocument();
    expect(screen.getByLabelText('Срок (месяцы)')).toBeInTheDocument();
    expect(screen.getByLabelText('Процентная ставка')).toBeInTheDocument();
    expect(screen.getByText('Рассчитать')).toBeInTheDocument();
  });

  it('should handle successful calculation', async () => {
    const mockResult = {
      monthlyPayment: 1000,
      totalAmount: 12000,
      overpayment: 2000,
      schedule: [
        { date: '2024-01-01', payment: 1000, principal: 800, interest: 200, balance: 11000 },
        { date: '2024-02-01', payment: 1000, principal: 800, interest: 200, balance: 10000 }
      ]
    };

    mockCalculatePaymentSchedule.mockResolvedValue(mockResult);

    render(<PaymentCalculator />);

    fireEvent.change(screen.getByLabelText('Сумма кредита'), { target: { value: '10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '12' } });
    fireEvent.change(screen.getByLabelText('Процентная ставка'), { target: { value: '10' } });

    fireEvent.click(screen.getByText('Рассчитать'));

    await waitFor(() => {
      expect(screen.getByText('Ежемесячный платеж: 1 000,00 BYN')).toBeInTheDocument();
      expect(screen.getByText('Общая сумма: 12 000,00 BYN')).toBeInTheDocument();
      expect(screen.getByText('Переплата: 2 000,00 BYN')).toBeInTheDocument();
      expect(screen.getByText('График платежей')).toBeInTheDocument();
    });
  });

  it('should handle calculation error', async () => {
    mockCalculatePaymentSchedule.mockRejectedValue(new Error('Calculation failed'));

    render(<PaymentCalculator />);

    fireEvent.change(screen.getByLabelText('Сумма кредита'), { target: { value: '10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '12' } });
    fireEvent.change(screen.getByLabelText('Процентная ставка'), { target: { value: '10' } });

    fireEvent.click(screen.getByText('Рассчитать'));

    await waitFor(() => {
      expect(screen.getByText('Ошибка при расчете платежей')).toBeInTheDocument();
    });
  });

  it('should validate form fields', async () => {
    render(<PaymentCalculator />);

    fireEvent.click(screen.getByText('Рассчитать'));

    expect(screen.getByText('Сумма кредита обязательна')).toBeInTheDocument();
    expect(screen.getByText('Срок обязателен')).toBeInTheDocument();
    expect(screen.getByText('Процентная ставка обязательна')).toBeInTheDocument();
  });

  it('should validate numeric values', async () => {
    render(<PaymentCalculator />);

    fireEvent.change(screen.getByLabelText('Сумма кредита'), { target: { value: 'abc' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: 'xyz' } });
    fireEvent.change(screen.getByLabelText('Процентная ставка'), { target: { value: 'def' } });

    fireEvent.click(screen.getByText('Рассчитать'));

    expect(screen.getByText('Сумма кредита должна быть числом')).toBeInTheDocument();
    expect(screen.getByText('Срок должен быть числом')).toBeInTheDocument();
    expect(screen.getByText('Процентная ставка должна быть числом')).toBeInTheDocument();
  });

  it('should validate positive values', async () => {
    render(<PaymentCalculator />);

    fireEvent.change(screen.getByLabelText('Сумма кредита'), { target: { value: '-10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '-12' } });
    fireEvent.change(screen.getByLabelText('Процентная ставка'), { target: { value: '-10' } });

    fireEvent.click(screen.getByText('Рассчитать'));

    expect(screen.getByText('Сумма кредита должна быть положительной')).toBeInTheDocument();
    expect(screen.getByText('Срок должен быть положительным')).toBeInTheDocument();
    expect(screen.getByText('Процентная ставка должна быть положительной')).toBeInTheDocument();
  });
}); 