import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import { installmentService } from '../../services/installment.service';
import CreateInstallment from '../CreateInstallment';

jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn()
}));

jest.mock('../../services/installment.service');

describe('CreateInstallment', () => {
  const mockNavigate = jest.fn();
  const mockCreateInstallment = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    useNavigate.mockReturnValue(mockNavigate);
    installmentService.createInstallment = mockCreateInstallment;
  });

  it('should render create installment form', () => {
    render(<CreateInstallment />);

    expect(screen.getByLabelText('Название')).toBeInTheDocument();
    expect(screen.getByLabelText('Описание')).toBeInTheDocument();
    expect(screen.getByLabelText('Общая сумма')).toBeInTheDocument();
    expect(screen.getByLabelText('Срок (месяцы)')).toBeInTheDocument();
    expect(screen.getByLabelText('ID шаблона')).toBeInTheDocument();
    expect(screen.getByText('Создать рассрочку')).toBeInTheDocument();
  });

  it('should handle successful installment creation', async () => {
    const mockInstallment = {
      id: 1,
      title: 'Test Installment',
      description: 'Test Description',
      totalAmount: 10000,
      term: 12,
      templateId: 1
    };

    mockCreateInstallment.mockResolvedValue(mockInstallment);

    render(<CreateInstallment />);

    fireEvent.change(screen.getByLabelText('Название'), { target: { value: 'Test Installment' } });
    fireEvent.change(screen.getByLabelText('Описание'), { target: { value: 'Test Description' } });
    fireEvent.change(screen.getByLabelText('Общая сумма'), { target: { value: '10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '12' } });
    fireEvent.change(screen.getByLabelText('ID шаблона'), { target: { value: '1' } });

    fireEvent.click(screen.getByText('Создать рассрочку'));

    await waitFor(() => {
      expect(mockCreateInstallment).toHaveBeenCalledWith({
        title: 'Test Installment',
        description: 'Test Description',
        totalAmount: 10000,
        term: 12,
        templateId: 1
      });
      expect(mockNavigate).toHaveBeenCalledWith('/');
    });
  });

  it('should handle creation error', async () => {
    mockCreateInstallment.mockRejectedValue(new Error('Creation failed'));

    render(<CreateInstallment />);

    fireEvent.change(screen.getByLabelText('Название'), { target: { value: 'Test Installment' } });
    fireEvent.change(screen.getByLabelText('Описание'), { target: { value: 'Test Description' } });
    fireEvent.change(screen.getByLabelText('Общая сумма'), { target: { value: '10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '12' } });
    fireEvent.change(screen.getByLabelText('ID шаблона'), { target: { value: '1' } });

    fireEvent.click(screen.getByText('Создать рассрочку'));

    await waitFor(() => {
      expect(screen.getByText('Ошибка при создании рассрочки')).toBeInTheDocument();
    });
  });

  it('should validate form fields', async () => {
    render(<CreateInstallment />);

    fireEvent.click(screen.getByText('Создать рассрочку'));

    expect(screen.getByText('Название обязательно')).toBeInTheDocument();
    expect(screen.getByText('Описание обязательно')).toBeInTheDocument();
    expect(screen.getByText('Общая сумма обязательна')).toBeInTheDocument();
    expect(screen.getByText('Срок обязателен')).toBeInTheDocument();
    expect(screen.getByText('ID шаблона обязателен')).toBeInTheDocument();
  });

  it('should validate numeric values', async () => {
    render(<CreateInstallment />);

    fireEvent.change(screen.getByLabelText('Общая сумма'), { target: { value: 'abc' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: 'xyz' } });
    fireEvent.change(screen.getByLabelText('ID шаблона'), { target: { value: 'def' } });

    fireEvent.click(screen.getByText('Создать рассрочку'));

    expect(screen.getByText('Общая сумма должна быть числом')).toBeInTheDocument();
    expect(screen.getByText('Срок должен быть числом')).toBeInTheDocument();
    expect(screen.getByText('ID шаблона должен быть числом')).toBeInTheDocument();
  });

  it('should validate positive values', async () => {
    render(<CreateInstallment />);

    fireEvent.change(screen.getByLabelText('Общая сумма'), { target: { value: '-10000' } });
    fireEvent.change(screen.getByLabelText('Срок (месяцы)'), { target: { value: '-12' } });
    fireEvent.change(screen.getByLabelText('ID шаблона'), { target: { value: '-1' } });

    fireEvent.click(screen.getByText('Создать рассрочку'));

    expect(screen.getByText('Общая сумма должна быть положительной')).toBeInTheDocument();
    expect(screen.getByText('Срок должен быть положительным')).toBeInTheDocument();
    expect(screen.getByText('ID шаблона должен быть положительным')).toBeInTheDocument();
  });
}); 