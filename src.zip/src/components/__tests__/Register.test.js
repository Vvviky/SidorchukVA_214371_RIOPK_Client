import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Register from '../Register';

jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn()
}));

jest.mock('../../contexts/AuthContext');

describe('Register', () => {
  const mockNavigate = jest.fn();
  const mockRegister = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    useNavigate.mockReturnValue(mockNavigate);
    useAuth.mockReturnValue({ register: mockRegister });
  });

  it('should render registration form', () => {
    render(<Register />);

    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Пароль')).toBeInTheDocument();
    expect(screen.getByLabelText('Подтверждение пароля')).toBeInTheDocument();
    expect(screen.getByText('Зарегистрироваться')).toBeInTheDocument();
    expect(screen.getByText('Войти')).toBeInTheDocument();
  });

  it('should handle successful registration', async () => {
    mockRegister.mockResolvedValue({});
    render(<Register />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText('Подтверждение пароля'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Зарегистрироваться'));

    await waitFor(() => {
      expect(mockRegister).toHaveBeenCalledWith('test@example.com', 'password123');
      expect(mockNavigate).toHaveBeenCalledWith('/');
    });
  });

  it('should handle registration error', async () => {
    mockRegister.mockRejectedValue(new Error('Registration failed'));
    render(<Register />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText('Подтверждение пароля'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Зарегистрироваться'));

    await waitFor(() => {
      expect(screen.getByText('Ошибка при регистрации')).toBeInTheDocument();
    });
  });

  it('should validate form fields', async () => {
    render(<Register />);

    fireEvent.click(screen.getByText('Зарегистрироваться'));

    expect(screen.getByText('Email обязателен')).toBeInTheDocument();
    expect(screen.getByText('Пароль обязателен')).toBeInTheDocument();
    expect(screen.getByText('Подтверждение пароля обязательно')).toBeInTheDocument();
  });

  it('should validate email format', async () => {
    render(<Register />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'invalid-email' } });
    fireEvent.click(screen.getByText('Зарегистрироваться'));

    expect(screen.getByText('Неверный формат email')).toBeInTheDocument();
  });

  it('should validate password match', async () => {
    render(<Register />);

    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText('Подтверждение пароля'), { target: { value: 'different123' } });
    fireEvent.click(screen.getByText('Зарегистрироваться'));

    expect(screen.getByText('Пароли не совпадают')).toBeInTheDocument();
  });

  it('should navigate to login page', () => {
    render(<Register />);

    fireEvent.click(screen.getByText('Войти'));

    expect(mockNavigate).toHaveBeenCalledWith('/login');
  });

  it('should handle loading state', async () => {
    mockRegister.mockImplementation(() => new Promise(() => {}));
    render(<Register />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText('Пароль'), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText('Подтверждение пароля'), { target: { value: 'password123' } });

    fireEvent.click(screen.getByText('Зарегистрироваться'));

    expect(screen.getByText('Загрузка...')).toBeInTheDocument();
  });
}); 