import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Snackbar, Alert } from '@mui/material';
import { clearError as clearAuthError } from '../store/slices/authSlice';
import { clearError as clearInstallmentsError } from '../store/slices/installmentsSlice';
import { clearError as clearPaymentsError } from '../store/slices/paymentsSlice';
import './Notification.css';

const Notification = () => {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState('info');
  
  const dispatch = useDispatch();
  
  const authError = useSelector(state => state.auth.error);
  const installmentsError = useSelector(state => state.installments.error);
  const paymentsError = useSelector(state => state.payments.error);
  
  // Следим за ошибками из всех слайсов Redux
  useEffect(() => {
    if (authError) {
      setMessage(authError);
      setSeverity('error');
      setOpen(true);
    } else if (installmentsError) {
      setMessage(installmentsError);
      setSeverity('error');
      setOpen(true);
    } else if (paymentsError) {
      setMessage(paymentsError);
      setSeverity('error');
      setOpen(true);
    }
  }, [authError, installmentsError, paymentsError]);
  
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    
    setOpen(false);
    
    // Очищаем ошибки в Redux
    if (authError) dispatch(clearAuthError());
    if (installmentsError) dispatch(clearInstallmentsError());
    if (paymentsError) dispatch(clearPaymentsError());
  };
  
  // Функция для отображения пользовательского уведомления
  // Может быть использована извне через диспетчер событий
  const showCustomNotification = (msg, type = 'info') => {
    setMessage(msg);
    setSeverity(type);
    setOpen(true);
  };
  
  // Добавляем слушатель событий для показа уведомлений из любой части приложения
  useEffect(() => {
    const eventHandler = event => {
      const { message, type } = event.detail;
      showCustomNotification(message, type);
    };
    
    window.addEventListener('show-notification', eventHandler);
    
    return () => {
      window.removeEventListener('show-notification', eventHandler);
    };
  }, []);
  
  return (
    <Snackbar
      open={open}
      autoHideDuration={6000}
      onClose={handleClose}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
    >
      <Alert onClose={handleClose} severity={severity} sx={{ width: '100%' }}>
        {message}
      </Alert>
    </Snackbar>
  );
};

// Вспомогательная функция для показа уведомлений из любого компонента
export const showNotification = (message, type = 'info') => {
  window.dispatchEvent(
    new CustomEvent('show-notification', { 
      detail: { message, type }
    })
  );
};

export default Notification; 