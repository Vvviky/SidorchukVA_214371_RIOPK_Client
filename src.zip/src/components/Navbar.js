import React, { useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../store/slices/authSlice';
import AppBar from '@mui/material/AppBar';
import { 
  Toolbar, Typography, Button, Box, Avatar, IconButton, Menu, MenuItem,
  Divider, ListItemIcon, Badge, Tooltip, ButtonGroup, Chip
} from '@mui/material';
import { 
  AccountCircle, Dashboard, Payment, Add, Calculate, ExitToApp, 
  AdminPanelSettings, ViewList, People, BarChart, Settings,
  Notifications, SupervisorAccount, ListAlt, InsertChart
} from '@mui/icons-material';

const Navbar = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [adminMenuAnchorEl, setAdminMenuAnchorEl] = React.useState(null);
  const dispatch = useDispatch();
  const location = useLocation();
  const { user, isAuthenticated } = useSelector(state => state.auth);
  
  // Проверяем, является ли пользователь администратором
  const isAdmin = React.useMemo(() => {
    return user && (user.isAdmin || user.role === 'admin');
  }, [user]);
  
  // Проверяем, находимся ли мы на странице администратора
  const isAdminPage = location.pathname.startsWith('/admin');

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleAdminMenuOpen = (event) => {
    setAdminMenuAnchorEl(event.currentTarget);
  };

  const handleAdminMenuClose = () => {
    setAdminMenuAnchorEl(null);
  };

  const handleLogout = () => {
    dispatch(logout());
    handleClose();
  };

  // Эффект для логирования состояния пользователя
  useEffect(() => {
    if (user) {
      console.log('Навигация - пользователь:', user);
      console.log('Навигация - администратор:', isAdmin);
    }
  }, [user, isAdmin]);

  if (!isAuthenticated) {
    return (
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component={Link} to="/" sx={{ flexGrow: 1, textDecoration: 'none', color: 'white' }}>
            Smart Split
          </Typography>
          <Button color="inherit" component={Link} to="/login">Вход</Button>
          <Button color="inherit" component={Link} to="/register">Регистрация</Button>
        </Toolbar>
      </AppBar>
    );
  }

  // Панель навигации для администратора
  if (isAdmin) {
    return (
      <AppBar 
        position="static" 
        sx={{
          bgcolor: isAdminPage ? 'error.main' : 'primary.main',
          transition: 'background-color 0.3s ease'
        }}
      >
        <Toolbar>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <SupervisorAccount sx={{ mr: 1 }} />
            <Typography 
              variant="h6" 
              component={Link} 
              to="/admin" 
              sx={{ textDecoration: 'none', color: 'white', fontWeight: 'bold' }}
            >
              Smart Split Admin
            </Typography>
          </Box>
          
          <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'center' }}>
            <ButtonGroup 
              variant="contained" 
              disableElevation 
              color="inherit"
              sx={{ ml: 2 }}
            >
              <Button 
                component={Link} 
                to="/admin" 
                startIcon={<Dashboard />}
                variant={location.pathname === '/admin' ? 'outlined' : 'text'}
              >
                Панель
              </Button>
              
              <Button 
                component={Link} 
                to="/admin/users" 
                startIcon={<People />}
                variant={location.pathname === '/admin/users' ? 'outlined' : 'text'}
              >
                Пользователи
              </Button>
              
              <Button 
                component={Link} 
                to="/admin/installments" 
                startIcon={<Payment />}
                variant={location.pathname === '/admin/installments' ? 'outlined' : 'text'}
              >
                Рассрочки
              </Button>
              
              <Button 
                component={Link} 
                to="/admin/templates" 
                startIcon={<ListAlt />}
                variant={location.pathname === '/admin/templates' ? 'outlined' : 'text'}
              >
                Шаблоны
              </Button>
              
              <Button 
                component={Link} 
                to="/admin/stats" 
                startIcon={<InsertChart />}
                variant={location.pathname === '/admin/stats' ? 'outlined' : 'text'}
              >
                Статистика
              </Button>
            </ButtonGroup>
          </Box>
          
          <Tooltip title="Режим пользователя">
            <Button 
              color="inherit" 
              component={Link} 
              to="/" 
              sx={{ mr: 2, bgcolor: 'rgba(0, 0, 0, 0.1)' }}
              startIcon={<Dashboard />}
            >
              Обычный режим
            </Button>
          </Tooltip>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Chip 
              label="Администратор" 
              color="secondary" 
              size="small" 
              sx={{ mr: 1 }}
            />
            
            <IconButton
              size="large"
              onClick={handleMenu}
              color="inherit"
            >
              {user.name ? (
                <Avatar sx={{ width: 32, height: 32, bgcolor: 'secondary.main' }}>
                  {user.name.charAt(0).toUpperCase()}
                </Avatar>
              ) : (
                <AccountCircle />
              )}
            </IconButton>
          </Box>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem disabled>
              {user.name || user.email}
              <Badge 
                sx={{ ml: 1 }} 
                badgeContent={"Админ"} 
                color="error"
              />
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout}>
              <ListItemIcon>
                <ExitToApp fontSize="small" />
              </ListItemIcon>
              Выйти
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
    );
  }

  // Панель навигации для обычного пользователя
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" component={Link} to="/" sx={{ flexGrow: 1, textDecoration: 'none', color: 'white' }}>
          Smart Split
        </Typography>
        
        {user && (
          <>
            <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
              <Button 
                color="inherit" 
                component={Link} 
                to="/" 
                startIcon={<Dashboard />}
                sx={{ mr: 1 }}
              >
                Панель
              </Button>
              
              <Button 
                color="inherit" 
                component={Link} 
                to="/installments" 
                startIcon={<Payment />}
                sx={{ mr: 1 }}
              >
                Рассрочки
              </Button>
              
              <Button 
                color="inherit" 
                component={Link} 
                to="/create-installment" 
                startIcon={<Add />}
                sx={{ mr: 1 }}
              >
                Создать
              </Button>
              
              <Button 
                color="inherit" 
                component={Link} 
                to="/templates" 
                startIcon={<ViewList />}
                sx={{ mr: 1 }}
              >
                Шаблоны
              </Button>
              
              {/* <Button 
                color="inherit" 
                component={Link} 
                to="/calculator" 
                startIcon={<Calculate />}
                sx={{ mr: 1 }}
              >
                Калькулятор
              </Button> */}
              
              {isAdmin && (
                <Tooltip title="Режим администратора">
                  <Button 
                    color="error"
                    variant="contained"
                    component={Link} 
                    to="/admin" 
                    startIcon={<AdminPanelSettings />}
                    sx={{ mr: 1 }}
                  >
                    Админ панель
                  </Button>
                </Tooltip>
              )}
            </Box>

            <IconButton
              size="large"
              onClick={handleMenu}
              color="inherit"
            >
              {user.name ? (
                <Avatar sx={{ width: 32, height: 32, bgcolor: 'secondary.main' }}>
                  {user.name.charAt(0).toUpperCase()}
                </Avatar>
              ) : (
                <AccountCircle />
              )}
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem disabled>
                {user.name || user.email}
                {isAdmin && (
                  <Badge 
                    sx={{ ml: 1 }} 
                    badgeContent={"Админ"} 
                    color="error"
                  />
                )}
              </MenuItem>
              <Divider />
              <MenuItem onClick={handleLogout}>
                <ListItemIcon>
                  <ExitToApp fontSize="small" />
                </ListItemIcon>
                Выйти
              </MenuItem>
            </Menu>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;