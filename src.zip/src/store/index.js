import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import installmentsReducer from './slices/installmentsSlice';
import paymentsReducer from './slices/paymentsSlice';
import templatesReducer from './slices/templatesSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    installments: installmentsReducer,
    payments: paymentsReducer,
    templates: templatesReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Игнорируем определенные поля для сериализации 
        // в случае сложных объектов в состоянии
        ignoredActions: ['payments/updatePaymentStatus/fulfilled'],
        ignoredPaths: ['installments.currentInstallment'],
      },
    }),
  devTools: process.env.NODE_ENV !== 'production',
}); 