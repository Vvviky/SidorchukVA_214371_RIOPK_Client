import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const BUSINESS_API_URL = process.env.REACT_APP_BUSINESS_SERVICE_URL || 'http://localhost:5001/api';

// Создаем экземпляр API для бизнес-сервиса
const businessApi = axios.create({
  baseURL: BUSINESS_API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Интерцептор для добавления токена к запросам
businessApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// Обработка ошибок ответов
businessApi.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Асинхронные операции
export const fetchInstallmentPayments = createAsyncThunk(
  'payments/fetchInstallmentPayments',
  async (installmentId, { rejectWithValue }) => {
    try {
      console.log(`Запрос на получение платежей по рассрочке ID=${installmentId}`);
      const response = await businessApi.get(`/installments/${installmentId}/payments`, {
        params: { _t: new Date().getTime() } // Для избежания кэширования
      });
      console.log(`Ответ от сервера для платежей (ID=${installmentId}):`, response.data);
      
      // Проверка формата ответа и нормализация данных
      let payments = [];
      if (response.data) {
        if (Array.isArray(response.data)) {
          payments = response.data;
        } else if (response.data.data && Array.isArray(response.data.data)) {
          payments = response.data.data;
        } else if (response.data.payments && Array.isArray(response.data.payments)) {
          payments = response.data.payments;
        }
      }
      
      console.log(`Нормализованные платежи (ID=${installmentId}):`, payments);
      return { installmentId, payments };
    } catch (error) {
      console.error(`Ошибка при получении платежей (ID=${installmentId}):`, error.response?.data || error.message);
      return rejectWithValue(error.response?.data?.message || 'Ошибка при получении платежей');
    }
  }
);

export const fetchUserPayments = createAsyncThunk(
  'payments/fetchUserPayments',
  async (_, { rejectWithValue }) => {
    try {
      console.log('Запрос на получение платежей пользователя');
      const response = await businessApi.get('/payments/user');
      console.log('Ответ от сервера (платежи):', response.data);
      
      // Проверка формата данных и преобразование в массив, если нужно
      let payments = [];
      if (response.data) {
        if (Array.isArray(response.data)) {
          payments = response.data;
        } else if (Array.isArray(response.data.data)) {
          payments = response.data.data;
        } else if (response.data.payments && Array.isArray(response.data.payments)) {
          payments = response.data.payments;
        }
      }
      
      console.log('Обработанный массив платежей:', payments);
      return payments;
    } catch (error) {
      console.error('Ошибка при получении платежей:', error.response?.data?.message || error.message);
      return rejectWithValue(error.response?.data?.message || 'Не удалось получить платежи');
    }
  }
);

export const updatePaymentStatus = createAsyncThunk(
  'payments/updatePaymentStatus',
  async ({ paymentId, status }, { rejectWithValue }) => {
    try {
      const response = await businessApi.patch(`/payments/${paymentId}/status`, { status });
      return { paymentId, status, data: response.data };
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при обновлении статуса платежа');
    }
  }
);

export const createPayment = createAsyncThunk(
  'payments/createPayment',
  async (paymentData, { rejectWithValue }) => {
    try {
      console.log('Отправка запроса на создание платежа:', paymentData);
      const response = await businessApi.post('/payments/simulate', paymentData);
      console.log('Ответ при создании платежа:', response.data);
      return response.data;
    } catch (error) {
      console.error('Ошибка при создании платежа:', error.response?.data || error.message);
      return rejectWithValue(error.response?.data?.message || 'Ошибка при создании платежа');
    }
  }
);

export const fetchPaymentSchedule = createAsyncThunk(
  'payments/fetchPaymentSchedule',
  async (installmentId, { rejectWithValue }) => {
    try {
      const response = await businessApi.get(`/payments/${installmentId}/schedule`);
      return { installmentId, schedule: response.data };
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при получении графика платежей');
    }
  }
);

export const fetchOverduePayments = createAsyncThunk(
  'payments/fetchOverduePayments',
  async (_, { rejectWithValue }) => {
    try {
      const response = await businessApi.get('/payments/overdue');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при получении просроченных платежей');
    }
  }
);

const initialState = {
  payments: [],
  installmentPayments: {},
  paymentSchedules: {},
  overduePayments: [],
  loading: false,
  error: null,
  currentPayment: null
};

const paymentsSlice = createSlice({
  name: 'payments',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCurrentPayment: (state, action) => {
      state.currentPayment = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      // Получение платежей по рассрочке
      .addCase(fetchInstallmentPayments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchInstallmentPayments.fulfilled, (state, action) => {
        state.loading = false;
        const { installmentId, payments } = action.payload;
        state.installmentPayments[installmentId] = payments;
      })
      .addCase(fetchInstallmentPayments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение всех платежей пользователя
      .addCase(fetchUserPayments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserPayments.fulfilled, (state, action) => {
        state.loading = false;
        // Проверяем, что action.payload - это массив
        if (Array.isArray(action.payload)) {
          state.payments = action.payload;
        } else {
          // Если не массив, то инициализируем пустым массивом
          console.error('Ошибка: платежи не являются массивом', action.payload);
          state.payments = [];
          state.error = 'Данные о платежах получены в неверном формате';
        }
      })
      .addCase(fetchUserPayments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Обновление статуса платежа
      .addCase(updatePaymentStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updatePaymentStatus.fulfilled, (state, action) => {
        state.loading = false;
        const { paymentId, status } = action.payload;
        
        // Обновляем в общем списке платежей
        state.payments = state.payments.map(payment => 
          payment.id === paymentId ? { ...payment, status } : payment
        );
        
        // Обновляем в списках платежей по рассрочкам
        Object.keys(state.installmentPayments).forEach(installmentId => {
          state.installmentPayments[installmentId] = state.installmentPayments[installmentId].map(
            payment => payment.id === paymentId ? { ...payment, status } : payment
          );
        });
        
        // Обновляем текущий платеж
        if (state.currentPayment && state.currentPayment.id === paymentId) {
          state.currentPayment = { ...state.currentPayment, status };
        }
      })
      .addCase(updatePaymentStatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Создание платежа
      .addCase(createPayment.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createPayment.fulfilled, (state, action) => {
        state.loading = false;
        const newPayment = action.payload;
        state.payments.push(newPayment);
        
        if (state.installmentPayments[newPayment.installmentId]) {
          state.installmentPayments[newPayment.installmentId].push(newPayment);
        }
      })
      .addCase(createPayment.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение графика платежей
      .addCase(fetchPaymentSchedule.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPaymentSchedule.fulfilled, (state, action) => {
        state.loading = false;
        const { installmentId, schedule } = action.payload;
        state.paymentSchedules[installmentId] = schedule;
      })
      .addCase(fetchPaymentSchedule.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение просроченных платежей
      .addCase(fetchOverduePayments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchOverduePayments.fulfilled, (state, action) => {
        state.loading = false;
        state.overduePayments = action.payload;
      })
      .addCase(fetchOverduePayments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export const { clearError, setCurrentPayment } = paymentsSlice.actions;
export default paymentsSlice.reducer; 