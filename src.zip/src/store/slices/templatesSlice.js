import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const BUSINESS_API_URL = process.env.REACT_APP_BUSINESS_SERVICE_URL || 'http://localhost:5001/api';

// Создаем экземпляр API для бизнес-сервиса
const businessApi = axios.create({
  baseURL: BUSINESS_API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Интерцептор для добавления токена к запросам
businessApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// Обработка ошибок ответов
businessApi.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Определение асинхронных thunks
export const fetchAllTemplates = createAsyncThunk(
  'templates/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await businessApi.get('/templates');
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось загрузить шаблоны';
      console.error('Error fetching templates:', message);
      return rejectWithValue(message);
    }
  }
);

export const fetchActiveTemplates = createAsyncThunk(
  'templates/fetchActive',
  async (_, { rejectWithValue }) => {
    try {
      const response = await businessApi.get('/templates/active');
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось загрузить активные шаблоны';
      console.error('Error fetching active templates:', message);
      return rejectWithValue(message);
    }
  }
);

export const createTemplate = createAsyncThunk(
  'templates/create',
  async (templateData, { rejectWithValue }) => {
    try {
      const response = await businessApi.post('/templates', templateData);
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось создать шаблон';
      console.error('Error creating template:', message);
      return rejectWithValue(message);
    }
  }
);

export const updateTemplate = createAsyncThunk(
  'templates/update',
  async ({ id, data }, { rejectWithValue }) => {
    try {
      const response = await businessApi.put(`/templates/${id}`, data);
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось обновить шаблон';
      console.error('Error updating template:', message);
      return rejectWithValue(message);
    }
  }
);

export const deleteTemplate = createAsyncThunk(
  'templates/delete',
  async (id, { rejectWithValue }) => {
    try {
      await businessApi.delete(`/templates/${id}`);
      return id;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось удалить шаблон';
      console.error('Error deleting template:', message);
      return rejectWithValue(message);
    }
  }
);

export const toggleTemplateStatus = createAsyncThunk(
  'templates/toggleStatus',
  async ({ id, isActive }, { rejectWithValue }) => {
    try {
      const response = await businessApi.patch(`/templates/${id}/status`, { isActive });
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || 'Не удалось изменить статус шаблона';
      console.error('Error toggling template status:', message);
      return rejectWithValue(message);
    }
  }
);

// Инициальное состояние
const initialState = {
  templates: [],
  activeTemplates: [],
  loading: false,
  error: null,
  currentTemplate: null
};

// Создание слайса
const templatesSlice = createSlice({
  name: 'templates',
  initialState,
  reducers: {
    clearTemplateErrors: (state) => {
      state.error = null;
    },
    setCurrentTemplate: (state, action) => {
      state.currentTemplate = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      // fetchAllTemplates
      .addCase(fetchAllTemplates.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllTemplates.fulfilled, (state, action) => {
        state.loading = false;
        state.templates = action.payload;
      })
      .addCase(fetchAllTemplates.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // fetchActiveTemplates
      .addCase(fetchActiveTemplates.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchActiveTemplates.fulfilled, (state, action) => {
        state.loading = false;
        state.activeTemplates = action.payload;
      })
      .addCase(fetchActiveTemplates.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // createTemplate
      .addCase(createTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createTemplate.fulfilled, (state, action) => {
        state.loading = false;
        state.templates.push(action.payload);
        if (action.payload.isActive) {
          state.activeTemplates.push(action.payload);
        }
      })
      .addCase(createTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // updateTemplate
      .addCase(updateTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateTemplate.fulfilled, (state, action) => {
        state.loading = false;
        // Обновление шаблона в массиве всех шаблонов
        const index = state.templates.findIndex(t => t.id === action.payload.id);
        if (index !== -1) {
          state.templates[index] = action.payload;
        }
        
        // Обновление шаблона в массиве активных шаблонов
        const activeIndex = state.activeTemplates.findIndex(t => t.id === action.payload.id);
        if (action.payload.isActive) {
          if (activeIndex !== -1) {
            state.activeTemplates[activeIndex] = action.payload;
          } else {
            state.activeTemplates.push(action.payload);
          }
        } else if (activeIndex !== -1) {
          state.activeTemplates.splice(activeIndex, 1);
        }
      })
      .addCase(updateTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // deleteTemplate
      .addCase(deleteTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteTemplate.fulfilled, (state, action) => {
        state.loading = false;
        // Удаление шаблона из массива всех шаблонов
        state.templates = state.templates.filter(t => t.id !== action.payload);
        
        // Удаление шаблона из массива активных шаблонов
        state.activeTemplates = state.activeTemplates.filter(t => t.id !== action.payload);
      })
      .addCase(deleteTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // toggleTemplateStatus
      .addCase(toggleTemplateStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(toggleTemplateStatus.fulfilled, (state, action) => {
        state.loading = false;
        
        // Обновление статуса в массиве всех шаблонов
        const index = state.templates.findIndex(t => t.id === action.payload.id);
        if (index !== -1) {
          state.templates[index] = action.payload;
        }
        
        // Обновление в массиве активных шаблонов
        const activeIndex = state.activeTemplates.findIndex(t => t.id === action.payload.id);
        
        if (action.payload.isActive && activeIndex === -1) {
          // Если шаблон стал активным и его нет в активных - добавить
          state.activeTemplates.push(action.payload);
        } else if (!action.payload.isActive && activeIndex !== -1) {
          // Если шаблон стал неактивным и он есть в активных - удалить
          state.activeTemplates.splice(activeIndex, 1);
        }
      })
      .addCase(toggleTemplateStatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export const { clearTemplateErrors, setCurrentTemplate } = templatesSlice.actions;

export default templatesSlice.reducer; 