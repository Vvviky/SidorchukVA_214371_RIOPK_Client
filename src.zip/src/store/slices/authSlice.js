import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const AUTH_API_URL = process.env.REACT_APP_AUTH_SERVICE_URL || 'http://localhost:5000/api';

// Создаем экземпляр API для сервиса аутентификации
const authApi = axios.create({
  baseURL: `${AUTH_API_URL}/auth`,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Интерцептор для добавления токена к запросам
authApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// Асинхронные операции
export const login = createAsyncThunk(
  'auth/login',
  async (credentials, { rejectWithValue }) => {
    try {
      const response = await authApi.post('/login', credentials);
      const data = response.data;
      
      if (data && data.token) {
        localStorage.setItem('token', data.token);
        return { user: data.user, token: data.token, role: data.user.role };
      }
      
      return rejectWithValue('Неверный ответ от сервера');
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при входе');
    }
  }
);

export const register = createAsyncThunk(
  'auth/register',
  async (userData, { rejectWithValue }) => {
    try {
      const response = await authApi.post('/register', userData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при регистрации');
    }
  }
);

export const fetchCurrentUser = createAsyncThunk(
  'auth/fetchCurrentUser',
  async (_, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      console.log('Проверка авторизации, токен:', token ? 'присутствует' : 'отсутствует');
      
      if (!token) {
        console.warn('Нет токена авторизации в localStorage');
        return rejectWithValue('Нет токена авторизации');
      }
      
      console.log('Отправка запроса на /me для получения данных пользователя');
      const response = await authApi.get('/me');
      console.log('Ответ от сервиса авторизации:', response.data);
      
      // Проверяем, что ответ содержит данные пользователя
      if (!response.data || !response.data.id) {
        console.error('Неверный формат данных пользователя:', response.data);
        localStorage.removeItem('token');
        return rejectWithValue('Неверный формат данных пользователя');
      }
      
      // Убедимся, что объект имеет необходимые свойства
      const userData = {
        ...response.data,
        role: response.data.role || 'user',
        isAdmin: response.data.role === 'admin' || response.data.isAdmin === true
      };
      
      console.log('Данные пользователя после обработки:', userData);
      return userData;
    } catch (error) {
      console.error('Ошибка при получении данных пользователя:', 
                    error.response?.data?.message || error.message);
      
      // Проверяем код ошибки и причину
      if (error.response) {
        console.error('Код ошибки:', error.response.status);
        console.error('Данные ошибки:', error.response.data);
        
        if (error.response.status === 401) {
          console.warn('Токен недействителен или истёк, удаляем из localStorage');
          localStorage.removeItem('token');
          return rejectWithValue('Токен авторизации недействителен');
        }
      }
      
      localStorage.removeItem('token');
      return rejectWithValue(
        error.response?.data?.message || 
        'Ошибка при получении данных пользователя. Пожалуйста, войдите снова.'
      );
    }
  }
);

export const fetchAllUsers = createAsyncThunk(
  'auth/fetchAllUsers',
  async (_, { rejectWithValue }) => {
    try {
      const response = await authApi.get('/users');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при получении списка пользователей');
    }
  }
);

export const updateUserRole = createAsyncThunk(
  'auth/updateUserRole',
  async ({ userId, role }, { rejectWithValue }) => {
    try {
      const response = await authApi.patch(`/users/${userId}/role`, { role });
      return { userId, role: response.data.role };
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при обновлении роли пользователя');
    }
  }
);

export const updateUserStatus = createAsyncThunk(
  'auth/updateUserStatus',
  async ({ userId, isActive }, { rejectWithValue }) => {
    try {
      const response = await authApi.patch(`/users/${userId}/status`, { isActive });
      return { userId, isActive: response.data.isActive };
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при обновлении статуса пользователя');
    }
  }
);

const initialState = {
  user: null,
  token: localStorage.getItem('token'),
  role: null,
  isAuthenticated: !!localStorage.getItem('token'),
  loading: false,
  error: null,
  users: [],
  usersLoading: false,
  usersError: null
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      localStorage.removeItem('token');
      state.user = null;
      state.token = null;
      state.role = null;
      state.isAuthenticated = false;
      state.error = null;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Логин
      .addCase(login.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.loading = false;
        console.log('Ответ от сервера при логине:', action.payload);
        state.user = action.payload.user;
        
        // Устанавливаем isAdmin на основе роли и флага isAdmin
        if (action.payload.user) {
          state.user.isAdmin = action.payload.user.role === 'admin' || !!action.payload.user.isAdmin;
          console.log('Установлен isAdmin флаг при логине:', state.user.isAdmin);
        }
        
        state.token = action.payload.token;
        state.role = action.payload.role;
        state.isAuthenticated = true;
      })
      .addCase(login.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Регистрация
      .addCase(register.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(register.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(register.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение текущего пользователя
      .addCase(fetchCurrentUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCurrentUser.fulfilled, (state, action) => {
        state.loading = false;
        console.log('Ответ от сервера при получении текущего пользователя:', action.payload);
        state.user = action.payload;
        
        // Устанавливаем isAdmin на основе роли и флага isAdmin
        if (action.payload) {
          state.user.isAdmin = action.payload.role === 'admin' || !!action.payload.isAdmin;
          console.log('Установлен isAdmin флаг:', state.user.isAdmin);
        }
        
        state.role = action.payload.role;
        state.isAuthenticated = true;
      })
      .addCase(fetchCurrentUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.isAuthenticated = false;
        state.user = null;
      })
      
      // Получение всех пользователей
      .addCase(fetchAllUsers.pending, (state) => {
        state.usersLoading = true;
        state.usersError = null;
      })
      .addCase(fetchAllUsers.fulfilled, (state, action) => {
        state.usersLoading = false;
        state.users = action.payload;
      })
      .addCase(fetchAllUsers.rejected, (state, action) => {
        state.usersLoading = false;
        state.usersError = action.payload;
      })
      
      // Обновление роли пользователя
      .addCase(updateUserRole.fulfilled, (state, action) => {
        const { userId, role } = action.payload;
        state.users = state.users.map(user => 
          user.id === userId ? { ...user, role } : user
        );
      })
      
      // Обновление статуса пользователя
      .addCase(updateUserStatus.fulfilled, (state, action) => {
        const { userId, isActive } = action.payload;
        state.users = state.users.map(user => 
          user.id === userId ? { ...user, isActive } : user
        );
      });
  }
});

export const { logout, clearError } = authSlice.actions;
export default authSlice.reducer; 