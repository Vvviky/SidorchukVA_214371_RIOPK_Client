import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const BUSINESS_API_URL = process.env.REACT_APP_BUSINESS_SERVICE_URL || 'http://localhost:5001/api';

// Создаем экземпляр API для бизнес-сервиса
const businessApi = axios.create({
  baseURL: BUSINESS_API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Интерцептор для добавления токена к запросам
businessApi.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// Обработка ошибок ответов
businessApi.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Асинхронные операции
export const fetchUserInstallments = createAsyncThunk(
  'installments/fetchUserInstallments',
  async (_, { rejectWithValue }) => {
    try {
      console.log('Запрос на получение списка рассрочек пользователя...');
      // Добавляем timestamp для предотвращения кэширования и получения актуальных данных
      const response = await businessApi.get('/installments', {
        params: { _t: new Date().getTime() }
      });
      console.log('Список рассрочек получен:', response.data);
      
      // Проверка формата ответа и нормализация данных
      let installments = [];
      if (response.data) {
        if (Array.isArray(response.data)) {
          installments = response.data;
        } else if (response.data.data && Array.isArray(response.data.data)) {
          installments = response.data.data;
        }
      }
      
      console.log('Нормализованный список рассрочек:', installments);
      return installments;
    } catch (error) {
      console.error('Ошибка при получении списка рассрочек:', error.response?.data || error.message);
      return rejectWithValue(error.response?.data?.message || 'Не удалось получить список рассрочек');
    }
  }
);

export const fetchAdminInstallments = createAsyncThunk(
  'installments/fetchAdminInstallments',
  async (filters = {}, { rejectWithValue }) => {
    try {
      console.log('Отправка запроса на получение всех рассрочек (админ)');
      // Создаем строку запроса из фильтров
      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) queryParams.append(key, value);
      });
      
      const url = '/installments/admin' + (queryParams.toString() ? `?${queryParams.toString()}` : '');
      const response = await businessApi.get(url);
      console.log('Ответ от сервера (админ рассрочки):', response.data);
      
      // Проверяем формат ответа
      if (response.data && response.data.data) {
        // API возвращает данные в формате { data: [...] }
        return response.data.data;
      } else if (Array.isArray(response.data)) {
        // API возвращает данные как массив
        return response.data;
      } else {
        console.error('Неверный формат данных (админ):', response.data);
        return [];
      }
    } catch (error) {
      console.error('Ошибка при получении рассрочек (админ):', error.response?.data || error.message);
      return rejectWithValue(error.response?.data?.message || 'Ошибка при получении рассрочек');
    }
  }
);

export const fetchInstallmentDetails = createAsyncThunk(
  'installments/fetchInstallmentDetails',
  async (id, { rejectWithValue }) => {
    try {
      console.log(`Запрос на получение деталей рассрочки с ID: ${id}, timestamp: ${new Date().toISOString()}`);
      
      // Добавляем уникальный timestamp и случайное число для гарантированного пропуска кэша
      const response = await businessApi.get(`/installments/${id}`, {
        params: { 
          _t: new Date().getTime(),
          _r: Math.random()
        },
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
      
      console.log('Детали рассрочки получены:', response.data);
      return response.data;
    } catch (error) {
      console.error('Ошибка при получении деталей рассрочки:', error.response?.data || error.message);
      return rejectWithValue(error.response?.data?.message || 'Не удалось получить детали рассрочки');
    }
  }
);

export const createInstallment = createAsyncThunk(
  'installments/createInstallment',
  async (installmentData, { rejectWithValue, getState }) => {
    try {
      // Получаем ID пользователя из состояния авторизации
      const { auth } = getState();
      const userId = auth.user?.id;
      
      // Добавляем ID пользователя к данным рассрочки
      const data = { ...installmentData, userId };
      console.log('Отправка запроса на создание рассрочки с данными:', data);
      
      const response = await businessApi.post('/installments', data);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Ошибка при создании рассрочки');
    }
  }
);

export const fetchInstallmentTemplates = createAsyncThunk(
  'installments/fetchInstallmentTemplates',
  async (_, { rejectWithValue }) => {
    try {
      const response = await businessApi.get('/templates/active');
      return response.data;
    } catch (error) {
      console.error('Error fetching templates:', error.response?.data?.message || error.message);
      return rejectWithValue(error.response?.data?.message || 'Не удалось загрузить шаблоны рассрочек');
    }
  }
);

export const createInstallmentFromTemplate = createAsyncThunk(
  'installments/createInstallmentFromTemplate',
  async (templateId, { rejectWithValue, getState }) => {
    try {
      // Получаем ID пользователя из состояния авторизации
      const { auth } = getState();
      const userId = auth.user?.id;
      
      console.log(`Создание рассрочки из шаблона ${templateId} для пользователя ${userId}`);
      
      // Отправляем ID пользователя в теле запроса
      const response = await businessApi.post(`/installments/template/${templateId}`, { userId });
      return response.data.data;
    } catch (error) {
      console.error('Error creating installment from template:', error.response?.data?.message || error.message);
      return rejectWithValue(error.response?.data?.message || 'Не удалось создать рассрочку на основе шаблона');
    }
  }
);

export const updateInstallmentStatus = createAsyncThunk(
  'installments/updateInstallmentStatus',
  async ({ id, status, reason }, { rejectWithValue }) => {
    try {
      // Используем исходный ID без преобразований
      console.log(`Обновление статуса рассрочки: ID=${id}, статус=${status}`);
      
      let url;
      
      // Выбор правильного эндпоинта в зависимости от статуса
      if (status === 'approved') {
        url = `/installments/admin/${id}/approve`;
        console.log(`Используем эндпоинт для одобрения: ${url}`);
      } else if (status === 'rejected') {
        url = `/installments/admin/${id}/reject`;
        console.log(`Используем эндпоинт для отклонения: ${url}`);
      } else if (status === 'active') {
        url = `/installments/${id}/activate`;
      } else if (status === 'cancelled') {
        url = `/installments/${id}/cancel`;
      } else {
        console.error(`Неподдерживаемый статус рассрочки: ${status}`);
        return rejectWithValue('Неподдерживаемый статус рассрочки');
      }
      
      // Подготавливаем данные для запроса
      const requestData = {};
      if (reason) {
        requestData.reason = reason;
      }
      
      // Отправляем запрос с данными
      console.log(`Отправка запроса: ${url}`, requestData);
      const response = await businessApi.patch(url, requestData);
      console.log('Ответ от сервера:', response.data);
      
      return { id, status, data: response.data };
    } catch (error) {
      console.error('Ошибка при обновлении статуса рассрочки:', error);
      console.error('Подробная информация об ошибке:', error.response?.data);
      return rejectWithValue(error.response?.data?.message || 'Ошибка при обновлении статуса рассрочки');
    }
  }
);

const initialState = {
  userInstallments: [],
  adminInstallments: [],
  currentInstallment: null,
  templates: [],
  loading: false,
  error: null,
  templatesLoading: false,
  templatesError: null
};

const installmentsSlice = createSlice({
  name: 'installments',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCurrentInstallment: (state, action) => {
      state.currentInstallment = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      // Получение рассрочек пользователя
      .addCase(fetchUserInstallments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserInstallments.fulfilled, (state, action) => {
        state.loading = false;
        
        // Проверяем данные, которые пришли
        console.log('Данные, полученные в reducer:', action.payload);
        
        // Если пришел массив, устанавливаем его. Иначе - пустой массив
        if (Array.isArray(action.payload)) {
          state.userInstallments = action.payload;
          
          // Форматируем даты при необходимости
          state.userInstallments = action.payload.map(item => {
            // Если нет даты создания, добавляем ее
            if (!item.createdAt) {
              return { ...item, createdAt: new Date().toISOString() };
            }
            
            // Проверяем корректность даты
            try {
              const date = new Date(item.createdAt);
              if (isNaN(date.getTime())) {
                return { ...item, createdAt: new Date().toISOString() };
              }
            } catch (e) {
              return { ...item, createdAt: new Date().toISOString() };
            }
            
            return item;
          });
        } else {
          // Если не массив, инициализируем пустым массивом
          console.warn('Ответ от сервера не является массивом:', action.payload);
          state.userInstallments = [];
        }
        
        console.log('Установлены userInstallments:', state.userInstallments);
      })
      .addCase(fetchUserInstallments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение всех рассрочек (для админа)
      .addCase(fetchAdminInstallments.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAdminInstallments.fulfilled, (state, action) => {
        state.loading = false;
        
        // Проверяем, что получен массив, и форматируем даты
        if (Array.isArray(action.payload)) {
          // Проверяем и исправляем даты для каждого элемента
          state.adminInstallments = action.payload.map(item => {
            // Если нет даты создания, добавляем ее
            if (!item.createdAt) {
              return { ...item, createdAt: new Date().toISOString() };
            }
            
            // Проверяем корректность даты
            try {
              const date = new Date(item.createdAt);
              if (isNaN(date.getTime())) {
                return { ...item, createdAt: new Date().toISOString() };
              }
            } catch (e) {
              return { ...item, createdAt: new Date().toISOString() };
            }
            
            return item;
          });
        } else {
          // Если не массив, инициализируем пустым массивом
          state.adminInstallments = [];
        }
      })
      .addCase(fetchAdminInstallments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение деталей рассрочки
      .addCase(fetchInstallmentDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchInstallmentDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.currentInstallment = action.payload;
      })
      .addCase(fetchInstallmentDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Создание рассрочки
      .addCase(createInstallment.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createInstallment.fulfilled, (state, action) => {
        state.loading = false;
        // Инициализируем массив, если он не существует
        if (!state.userInstallments) {
          state.userInstallments = [];
        }
        
        // Проверка, что payload содержит данные и имеет необходимые поля
        if (action.payload && action.payload.id) {
          // Проверяем, что createdAt - корректная дата
          if (action.payload.createdAt) {
            try {
              // Пробуем создать дату из полученного значения
              const date = new Date(action.payload.createdAt);
              // Если дата невалидна, устанавливаем текущее время
              if (isNaN(date.getTime())) {
                action.payload.createdAt = new Date().toISOString();
              }
            } catch (e) {
              action.payload.createdAt = new Date().toISOString();
            }
          } else {
            // Если дата отсутствует, добавляем текущую дату
            action.payload.createdAt = new Date().toISOString();
          }
          
          // Правильная проверка, чтобы убедиться, что работаем с массивом
          if (Array.isArray(state.userInstallments)) {
            state.userInstallments.push(action.payload);
          } else {
            state.userInstallments = [action.payload];
          }
        }
      })
      .addCase(createInstallment.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Создание рассрочки из шаблона
      .addCase(createInstallmentFromTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createInstallmentFromTemplate.fulfilled, (state, action) => {
        state.loading = false;
        
        // Проверяем, что действительно получили данные
        if (action.payload) {
          // Убеждаемся, что userInstallments - это массив
          if (!Array.isArray(state.userInstallments)) {
            state.userInstallments = [];
          }
          
          // Проверка и форматирование даты
          let installment = { ...action.payload };
          if (!installment.createdAt) {
            installment.createdAt = new Date().toISOString();
          } else {
            try {
              const date = new Date(installment.createdAt);
              if (isNaN(date.getTime())) {
                installment.createdAt = new Date().toISOString();
              }
            } catch (e) {
              installment.createdAt = new Date().toISOString();
            }
          }
          
          // Добавляем новую рассрочку в массив
          state.userInstallments.push(installment);
        }
      })
      .addCase(createInstallmentFromTemplate.rejected, (state, action) => {
        state.loading = false;
      state.error = action.payload;
      })
      
      // Обновление статуса рассрочки
      .addCase(updateInstallmentStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateInstallmentStatus.fulfilled, (state, action) => {
        state.loading = false;
      const { id, status } = action.payload;
        
        if (Array.isArray(state.userInstallments)) {
          state.userInstallments = state.userInstallments.map(installment => 
            installment.id === id ? { ...installment, status } : installment
          );
        }
        
        if (Array.isArray(state.adminInstallments)) {
          state.adminInstallments = state.adminInstallments.map(installment => 
            installment.id === id ? { ...installment, status } : installment
          );
        }
        
        if (state.currentInstallment && state.currentInstallment.id === id) {
          state.currentInstallment = { ...state.currentInstallment, status };
        }
      })
      .addCase(updateInstallmentStatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Получение шаблонов рассрочек
      .addCase(fetchInstallmentTemplates.pending, (state) => {
        state.templatesLoading = true;
        state.templatesError = null;
      })
      .addCase(fetchInstallmentTemplates.fulfilled, (state, action) => {
        state.templatesLoading = false;
        // Убедимся, что устанавливаем массив в state.templates
        state.templates = Array.isArray(action.payload) ? action.payload : [];
      })
      .addCase(fetchInstallmentTemplates.rejected, (state, action) => {
        state.templatesLoading = false;
        state.templatesError = action.payload;
      });
  }
});

export const { clearError, setCurrentInstallment } = installmentsSlice.actions;
export default installmentsSlice.reducer; 