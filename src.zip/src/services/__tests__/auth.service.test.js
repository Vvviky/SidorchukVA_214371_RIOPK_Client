import { authService } from '../auth.service';

describe('authService', () => {
  const mockUser = {
    id: 1,
    email: 'test@example.com',
    role: 'user'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should login successfully', async () => {
    const mockResponse = {
      token: 'test-token',
      user: mockUser
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockResponse)
    });

    const result = await authService.login('test@example.com', 'password123');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/auth/login',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: 'test@example.com',
          password: 'password123'
        })
      }
    );

    expect(result).toEqual(mockResponse);
  });

  it('should handle login error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: () => Promise.resolve({ message: 'Invalid credentials' })
    });

    await expect(authService.login('test@example.com', 'wrong-password')).rejects.toThrow('Invalid credentials');
  });

  it('should register successfully', async () => {
    const mockResponse = {
      token: 'test-token',
      user: mockUser
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockResponse)
    });

    const result = await authService.register('test@example.com', 'password123');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/auth/register',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: 'test@example.com',
          password: 'password123'
        })
      }
    );

    expect(result).toEqual(mockResponse);
  });

  it('should handle registration error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 400,
      json: () => Promise.resolve({ message: 'Email already exists' })
    });

    await expect(authService.register('existing@example.com', 'password123')).rejects.toThrow('Email already exists');
  });

  it('should get current user successfully', async () => {
    localStorage.setItem('token', 'test-token');

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockUser)
    });

    const result = await authService.getCurrentUser();

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/auth/me',
      {
        headers: {
          'Authorization': 'Bearer test-token'
        }
      }
    );

    expect(result).toEqual(mockUser);
  });

  it('should handle get current user error', async () => {
    localStorage.setItem('token', 'invalid-token');

    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: () => Promise.resolve({ message: 'Invalid token' })
    });

    await expect(authService.getCurrentUser()).rejects.toThrow('Invalid token');
  });

  it('should handle network error', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('Network error'));

    await expect(authService.login('test@example.com', 'password123')).rejects.toThrow('Network error');
  });

  it('should handle invalid response format', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ invalid: 'format' })
    });

    await expect(authService.login('test@example.com', 'password123')).rejects.toThrow('Invalid response format');
  });
}); 