import { calculationService } from '../calculation.service';

describe('calculationService', () => {
  const mockCalculation = {
    monthlyPayment: 1000,
    totalAmount: 12000,
    overpayment: 2000,
    schedule: [
      {
        date: '2024-01-01',
        payment: 1000,
        principal: 800,
        interest: 200,
        remaining: 11200
      }
    ]
  };

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.setItem('token', 'test-token');
  });

  it('should calculate monthly payment successfully', async () => {
    const calculationData = {
      amount: 10000,
      term: 12,
      interestRate: 10
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockCalculation)
    });

    const result = await calculationService.calculateMonthlyPayment(calculationData);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/calculations/monthly-payment',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(calculationData)
      }
    );

    expect(result).toEqual(mockCalculation);
  });

  it('should calculate payment schedule successfully', async () => {
    const calculationData = {
      amount: 10000,
      term: 12,
      interestRate: 10
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockCalculation)
    });

    const result = await calculationService.calculatePaymentSchedule(calculationData);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/calculations/schedule',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(calculationData)
      }
    );

    expect(result).toEqual(mockCalculation);
  });

  it('should calculate max amount successfully', async () => {
    const calculationData = {
      monthlyIncome: 5000,
      monthlyExpenses: 2000,
      term: 12,
      interestRate: 10
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockCalculation)
    });

    const result = await calculationService.calculateMaxAmount(calculationData);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/calculations/max-amount',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(calculationData)
      }
    );

    expect(result).toEqual(mockCalculation);
  });

  it('should handle calculation error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 400,
      json: () => Promise.resolve({ message: 'Invalid parameters' })
    });

    await expect(calculationService.calculateMonthlyPayment({})).rejects.toThrow('Invalid parameters');
  });

  it('should handle network error', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('Network error'));

    await expect(calculationService.calculateMonthlyPayment({})).rejects.toThrow('Network error');
  });

  it('should handle invalid response format', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ invalid: 'format' })
    });

    await expect(calculationService.calculateMonthlyPayment({})).rejects.toThrow('Invalid response format');
  });

  it('should validate calculation parameters', async () => {
    const invalidData = {
      amount: -10000,
      term: 0,
      interestRate: -10
    };

    await expect(calculationService.calculateMonthlyPayment(invalidData)).rejects.toThrow('Invalid parameters');
  });

  it('should handle unauthorized access', async () => {
    localStorage.removeItem('token');

    await expect(calculationService.calculateMonthlyPayment({})).rejects.toThrow('Unauthorized');
  });
}); 