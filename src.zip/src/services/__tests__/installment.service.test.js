import { installmentService } from '../installment.service';

describe('installmentService', () => {
  const mockInstallment = {
    id: 1,
    title: 'Test Installment',
    description: 'Test Description',
    totalAmount: 10000,
    term: 12,
    status: 'pending',
    createdAt: '2024-01-01T00:00:00.000Z'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.setItem('token', 'test-token');
  });

  it('should get installments successfully', async () => {
    const mockResponse = [mockInstallment];

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockResponse)
    });

    const result = await installmentService.getInstallments();

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/installments',
      {
        headers: {
          'Authorization': 'Bearer test-token'
        }
      }
    );

    expect(result).toEqual(mockResponse);
  });

  it('should create installment successfully', async () => {
    const createData = {
      title: 'Test Installment',
      description: 'Test Description',
      totalAmount: 10000,
      term: 12,
      templateId: 1
    };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockInstallment)
    });

    const result = await installmentService.createInstallment(createData);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/installments',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(createData)
      }
    );

    expect(result).toEqual(mockInstallment);
  });

  it('should approve installment successfully', async () => {
    const updatedInstallment = { ...mockInstallment, status: 'approved' };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(updatedInstallment)
    });

    const result = await installmentService.approveInstallment(1);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/installments/1/approve',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token'
        }
      }
    );

    expect(result).toEqual(updatedInstallment);
  });

  it('should reject installment successfully', async () => {
    const updatedInstallment = { ...mockInstallment, status: 'rejected' };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(updatedInstallment)
    });

    const result = await installmentService.rejectInstallment(1);

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:3001/api/installments/1/reject',
      {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-token'
        }
      }
    );

    expect(result).toEqual(updatedInstallment);
  });

  it('should handle get installments error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: () => Promise.resolve({ message: 'Unauthorized' })
    });

    await expect(installmentService.getInstallments()).rejects.toThrow('Unauthorized');
  });

  it('should handle create installment error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 400,
      json: () => Promise.resolve({ message: 'Invalid data' })
    });

    await expect(installmentService.createInstallment({})).rejects.toThrow('Invalid data');
  });

  it('should handle approve installment error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 403,
      json: () => Promise.resolve({ message: 'Forbidden' })
    });

    await expect(installmentService.approveInstallment(1)).rejects.toThrow('Forbidden');
  });

  it('should handle reject installment error', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 403,
      json: () => Promise.resolve({ message: 'Forbidden' })
    });

    await expect(installmentService.rejectInstallment(1)).rejects.toThrow('Forbidden');
  });

  it('should handle network error', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('Network error'));

    await expect(installmentService.getInstallments()).rejects.toThrow('Network error');
  });

  it('should handle invalid response format', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ invalid: 'format' })
    });

    await expect(installmentService.getInstallments()).rejects.toThrow('Invalid response format');
  });
}); 