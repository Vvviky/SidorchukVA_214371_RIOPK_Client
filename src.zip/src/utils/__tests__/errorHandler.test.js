import { handleApiError } from '../errorHandler';

describe('errorHandler', () => {
  it('should handle API error with message', () => {
    const error = {
      response: {
        status: 400,
        data: {
          message: 'Invalid input'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Invalid input');
  });

  it('should handle API error without message', () => {
    const error = {
      response: {
        status: 500,
        data: {}
      }
    };

    expect(() => handleApiError(error)).toThrow('Произошла ошибка при выполнении запроса');
  });

  it('should handle network error', () => {
    const error = {
      message: 'Network error'
    };

    expect(() => handleApiError(error)).toThrow('Ошибка сети. Проверьте подключение к интернету');
  });

  it('should handle unauthorized error', () => {
    const error = {
      response: {
        status: 401,
        data: {
          message: 'Unauthorized'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Необходима авторизация');
  });

  it('should handle forbidden error', () => {
    const error = {
      response: {
        status: 403,
        data: {
          message: 'Forbidden'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Доступ запрещен');
  });

  it('should handle not found error', () => {
    const error = {
      response: {
        status: 404,
        data: {
          message: 'Not found'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Запрашиваемый ресурс не найден');
  });

  it('should handle validation error', () => {
    const error = {
      response: {
        status: 422,
        data: {
          message: 'Validation failed',
          errors: {
            email: ['Invalid email format'],
            password: ['Password is too short']
          }
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Ошибка валидации: Invalid email format, Password is too short');
  });

  it('should handle conflict error', () => {
    const error = {
      response: {
        status: 409,
        data: {
          message: 'Conflict'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Конфликт данных');
  });

  it('should handle server error', () => {
    const error = {
      response: {
        status: 500,
        data: {
          message: 'Internal server error'
        }
      }
    };

    expect(() => handleApiError(error)).toThrow('Внутренняя ошибка сервера');
  });

  it('should handle unknown error', () => {
    const error = {};

    expect(() => handleApiError(error)).toThrow('Произошла неизвестная ошибка');
  });
}); 