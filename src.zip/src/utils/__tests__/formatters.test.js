import { formatCurrency, formatDate, formatDateTime } from '../formatters';

describe('formatters', () => {
  describe('formatCurrency', () => {
    it('should format positive numbers', () => {
      expect(formatCurrency(1000)).toBe('1 000,00 BYN');
      expect(formatCurrency(1234.56)).toBe('1 234,56 BYN');
      expect(formatCurrency(1000000)).toBe('1 000 000,00 BYN');
    });

    it('should format negative numbers', () => {
      expect(formatCurrency(-1000)).toBe('-1 000,00 BYN');
      expect(formatCurrency(-1234.56)).toBe('-1 234,56 BYN');
    });

    it('should format zero', () => {
      expect(formatCurrency(0)).toBe('0,00 BYN');
    });

    it('should handle string inputs', () => {
      expect(formatCurrency('1000')).toBe('1 000,00 BYN');
      expect(formatCurrency('1234.56')).toBe('1 234,56 BYN');
    });

    it('should handle invalid inputs', () => {
      expect(formatCurrency('invalid')).toBe('0,00 BYN');
      expect(formatCurrency(null)).toBe('0,00 BYN');
      expect(formatCurrency(undefined)).toBe('0,00 BYN');
    });
  });

  describe('formatDate', () => {
    it('should format date string', () => {
      expect(formatDate('2024-03-15')).toBe('15.03.2024');
    });

    it('should format Date object', () => {
      expect(formatDate(new Date('2024-03-15'))).toBe('15.03.2024');
    });

    it('should handle invalid inputs', () => {
      expect(formatDate('invalid')).toBe('Invalid Date');
      expect(formatDate(null)).toBe('Invalid Date');
      expect(formatDate(undefined)).toBe('Invalid Date');
    });
  });

  describe('formatDateTime', () => {
    it('should format date-time string', () => {
      expect(formatDateTime('2024-03-15T14:30:00')).toBe('15.03.2024 14:30');
    });

    it('should format Date object', () => {
      expect(formatDateTime(new Date('2024-03-15T14:30:00'))).toBe('15.03.2024 14:30');
    });

    it('should handle single-digit hours and minutes', () => {
      expect(formatDateTime('2024-03-15T09:05:00')).toBe('15.03.2024 09:05');
    });

    it('should handle invalid inputs', () => {
      expect(formatDateTime('invalid')).toBe('Invalid Date');
      expect(formatDateTime(null)).toBe('Invalid Date');
      expect(formatDateTime(undefined)).toBe('Invalid Date');
    });
  });
}); 