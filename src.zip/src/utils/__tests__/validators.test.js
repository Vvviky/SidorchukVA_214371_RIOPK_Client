import { validateEmail, validatePassword, validateAmount, validateTerm } from '../validators';

describe('validators', () => {
  describe('validateEmail', () => {
    it('should validate correct email', () => {
      expect(validateEmail('test@example.com')).toBe(true);
      expect(validateEmail('user.name@domain.co.uk')).toBe(true);
      expect(validateEmail('user+tag@example.com')).toBe(true);
    });

    it('should reject invalid email', () => {
      expect(validateEmail('test@')).toBe(false);
      expect(validateEmail('@example.com')).toBe(false);
      expect(validateEmail('test@example')).toBe(false);
      expect(validateEmail('test@.com')).toBe(false);
      expect(validateEmail('test@example..com')).toBe(false);
      expect(validateEmail('test example.com')).toBe(false);
    });

    it('should handle empty or undefined input', () => {
      expect(validateEmail('')).toBe(false);
      expect(validateEmail(null)).toBe(false);
      expect(validateEmail(undefined)).toBe(false);
    });
  });

  describe('validatePassword', () => {
    it('should validate correct password', () => {
      expect(validatePassword('Password123')).toBe(true);
      expect(validatePassword('P@ssw0rd')).toBe(true);
      expect(validatePassword('LongPassword123!')).toBe(true);
    });

    it('should reject invalid password', () => {
      expect(validatePassword('short')).toBe(false);
      expect(validatePassword('password')).toBe(false);
      expect(validatePassword('PASSWORD')).toBe(false);
      expect(validatePassword('12345678')).toBe(false);
      expect(validatePassword('Password')).toBe(false);
    });

    it('should handle empty or undefined input', () => {
      expect(validatePassword('')).toBe(false);
      expect(validatePassword(null)).toBe(false);
      expect(validatePassword(undefined)).toBe(false);
    });
  });

  describe('validateAmount', () => {
    it('should validate correct amount', () => {
      expect(validateAmount(1000)).toBe(true);
      expect(validateAmount(1000000)).toBe(true);
      expect(validateAmount(1234.56)).toBe(true);
    });

    it('should reject invalid amount', () => {
      expect(validateAmount(-1000)).toBe(false);
      expect(validateAmount(0)).toBe(false);
      expect(validateAmount('invalid')).toBe(false);
    });

    it('should handle empty or undefined input', () => {
      expect(validateAmount('')).toBe(false);
      expect(validateAmount(null)).toBe(false);
      expect(validateAmount(undefined)).toBe(false);
    });
  });

  describe('validateTerm', () => {
    it('should validate correct term', () => {
      expect(validateTerm(1)).toBe(true);
      expect(validateTerm(12)).toBe(true);
      expect(validateTerm(60)).toBe(true);
    });

    it('should reject invalid term', () => {
      expect(validateTerm(-1)).toBe(false);
      expect(validateTerm(0)).toBe(false);
      expect(validateTerm(61)).toBe(false);
      expect(validateTerm('invalid')).toBe(false);
    });

    it('should handle empty or undefined input', () => {
      expect(validateTerm('')).toBe(false);
      expect(validateTerm(null)).toBe(false);
      expect(validateTerm(undefined)).toBe(false);
    });
  });
}); 