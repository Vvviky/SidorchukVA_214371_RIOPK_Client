/**
 * Форматирует число в денежный формат
 * @param {number} amount - Сумма для форматирования
 * @param {string} currency - Валюта (по умолчанию рубль)
 * @returns {string} Отформатированная строка с суммой
 */
export const formatCurrency = (amount, currency = 'BYN') => {
  if (amount === undefined || amount === null) return `0 ${currency}`;
  
  try {
    // Форматируем число с разделителями тысяч
    const formatter = new Intl.NumberFormat('ru-RU', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
    
    return `${formatter.format(amount)} ${currency}`;
  } catch (error) {
    console.error('Ошибка форматирования суммы:', error);
    return `${amount} ${currency}`;
  }
};

/**
 * Форматирует дату в локализованный формат
 * @param {string|Date} date - Дата для форматирования
 * @returns {string} Отформатированная дата
 */
export const formatDate = (date) => {
  if (!date) return '—';
  
  try {
    const dateObj = new Date(date);
    
    // Проверка на валидность даты
    if (isNaN(dateObj.getTime())) {
      return '—';
    }
    
    // Возвращаем дату в формате DD.MM.YYYY
    return new Intl.DateTimeFormat('ru-RU').format(dateObj);
  } catch (error) {
    console.error('Ошибка форматирования даты:', error);
    return '—';
  }
};

export const formatDateTime = (date) => {
  return new Date(date).toLocaleString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

/**
 * Форматирует статус рассрочки для отображения
 * @param {string} status - Статус рассрочки
 * @returns {string} Отформатированный статус на русском языке
 */
export const formatStatus = (status) => {
  if (!status) return 'Неизвестно';
  
  // Приводим к верхнему регистру для единообразия проверки
  const upperStatus = status.toUpperCase?.() || status;
  
  switch (upperStatus) {
    case 'ACTIVE':
      return 'Активна';
    case 'PENDING':
      return 'Ожидает подтверждения';
    case 'APPROVED':
      return 'Одобрена';
    case 'REJECTED':
      return 'Отклонена';
    case 'COMPLETED':
    case 'CLOSED':
      return 'Закрыта';
    case 'OVERDUE':
      return 'Просрочена';
    case 'CANCELLED':
      return 'Отменена';
    default:
      return status;
  }
}; 