import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useParams,
  useNavigate
} from 'react-router-dom';
import { fetchCurrentUser } from './store/slices/authSlice';
import { fetchInstallmentDetails } from './store/slices/installmentsSlice';
import { fetchInstallmentPayments } from './store/slices/paymentsSlice';
import { Box, CircularProgress, Container, Paper, Typography, Grid, Button, Chip, Alert, Divider, TableContainer, Table, TableHead, TableBody, TableRow, TableCell } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { formatCurrency, formatDate } from './utils/formatters';

// Компоненты
import Navbar from './components/Navbar';
import Login from './components/Login';
import Register from './components/Register';
import InstallmentList from './components/InstallmentList';
import CreateInstallment from './components/CreateInstallment';
import PaymentCalculator from './components/PaymentCalculator';
import PaymentList from './components/PaymentList';
import UserDashboard from './components/user/UserDashboard';
import UsersList from './components/admin/UsersList';
import TemplatesList from './components/admin/TemplatesList';
import Statistics from './components/admin/Statistics';
import AdminDashboard from './components/admin/AdminDashboard';
import PaymentsList from './components/admin/PaymentsList';
import InstallmentsList from './components/admin/InstallmentsList';
import Notification from './components/Notification';
import Loader from './components/Loader';
import TemplateSelection from './components/user/TemplateSelection';
import PaymentSimulation from './components/PaymentSimulation';
import UserInstallmentsList from './components/user/UserInstallmentsList';

import './App.css';

// Защищенный маршрут
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useSelector(state => state.auth);
  
  if (loading) {
    return <Loader />;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  return children;
};

// Маршрут только для администраторов
const AdminRoute = ({ children }) => {
  const { isAuthenticated, loading, user } = useSelector(state => state.auth);
  
  if (loading) {
    return <Loader />;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  // Проверка роли пользователя (должен быть администратор)
  if (!user?.isAdmin && user?.role !== 'admin') {
    return <Navigate to="/" />;
  }
  
  return children;
};

// Создаю новый компонент InstallmentDetails
const InstallmentDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { currentInstallment, loading, error } = useSelector(state => state.installments);
  const { installmentPayments, loading: paymentsLoading } = useSelector(state => state.payments);
  const navigate = useNavigate();
  
  useEffect(() => {
    if (id) {
      dispatch(fetchInstallmentDetails(id));
      // Загружаем платежи по этой рассрочке
      dispatch(fetchInstallmentPayments(id));
    }
  }, [dispatch, id]);
  
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }
  
  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }
  
  if (!currentInstallment) {
    return <Alert severity="info">Рассрочка не найдена</Alert>;
  }
  
  const getStatusChip = (status) => {
    const statusMap = {
      'pending': { label: 'Ожидает одобрения', color: 'warning' },
      'active': { label: 'Активна', color: 'success' },
      'completed': { label: 'Завершена', color: 'info' },
      'cancelled': { label: 'Отменена', color: 'error' },
      'rejected': { label: 'Отклонена', color: 'error' }
    };
    
    const statusInfo = statusMap[status] || { label: status, color: 'default' };
    
    return (
      <Chip 
        label={statusInfo.label} 
        color={statusInfo.color} 
        size="small" 
      />
    );
  };
  
  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(-1)}
          sx={{ mb: 2 }}
        >
          Назад
        </Button>
        
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h4" gutterBottom>
            {currentInstallment.title}
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
              Статус:
            </Typography>
            {getStatusChip(currentInstallment.status)}
          </Box>
          
          {currentInstallment.description && (
            <Typography variant="body1" paragraph>
              {currentInstallment.description}
            </Typography>
          )}
          
          <Divider sx={{ my: 2 }} />
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <Typography variant="body2" color="text.secondary">
                Сумма рассрочки
              </Typography>
              <Typography variant="h6">
                {formatCurrency(currentInstallment.totalAmount)}
              </Typography>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Typography variant="body2" color="text.secondary">
                Оплачено
              </Typography>
              <Typography variant="h6">
                {formatCurrency(currentInstallment.paidAmount || 0)}
              </Typography>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Typography variant="body2" color="text.secondary">
                Осталось выплатить
              </Typography>
              <Typography variant="h6" color={(currentInstallment.totalAmount - currentInstallment.paidAmount) > 0 ? "error" : "success"}>
                {formatCurrency((currentInstallment.totalAmount - (currentInstallment.paidAmount || 0)).toFixed(2))}
              </Typography>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Typography variant="body2" color="text.secondary">
                Срок (месяцев)
              </Typography>
              <Typography variant="h6">
                {currentInstallment.term}
              </Typography>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Typography variant="body2" color="text.secondary">
                Дата создания
              </Typography>
              <Typography variant="h6">
                {formatDate(currentInstallment.createdAt)}
              </Typography>
            </Grid>
            
            {currentInstallment.startDate && (
              <Grid item xs={12} sm={4}>
                <Typography variant="body2" color="text.secondary">
                  Дата начала
                </Typography>
                <Typography variant="h6">
                  {formatDate(currentInstallment.startDate)}
                </Typography>
              </Grid>
            )}
            
            {currentInstallment.nextPaymentDate && (
              <Grid item xs={12} sm={4}>
                <Typography variant="body2" color="text.secondary">
                  Следующий платеж
                </Typography>
                <Typography variant="h6">
                  {formatDate(currentInstallment.nextPaymentDate)}
                </Typography>
              </Grid>
            )}
            
            {currentInstallment.nextPaymentAmount && (
              <Grid item xs={12} sm={4}>
                <Typography variant="body2" color="text.secondary">
                  Сумма следующего платежа
                </Typography>
                <Typography variant="h6">
                  {formatCurrency(currentInstallment.nextPaymentAmount)}
                </Typography>
              </Grid>
            )}
          </Grid>
          
          <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
            <Button 
              variant="contained" 
              color="primary"
              onClick={() => navigate(`/installments/${id}/payments`)}
            >
              Просмотреть все платежи
            </Button>
            
            {currentInstallment.status === 'active' && (currentInstallment.totalAmount - currentInstallment.paidAmount) > 0 && (
              <Button 
                variant="contained" 
                color="success"
                onClick={() => navigate(`/installments/${id}/payment`)}
              >
                Произвести платеж
              </Button>
            )}
          </Box>
        </Paper>
        
        {/* История платежей */}
        {/* <Paper sx={{ p: 3 }}>
          <Typography variant="h5" gutterBottom>
            История платежей
          </Typography>
          
          {paymentsLoading ? (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100px">
              <CircularProgress />
            </Box>
          ) : (
            <>
              {installmentPayments && installmentPayments.length > 0 ? (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Дата</TableCell>
                        <TableCell>Сумма</TableCell>
                        <TableCell>Статус</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {installmentPayments.map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>{formatDate(payment.paidAt || payment.dueDate)}</TableCell>
                          <TableCell>{formatCurrency(payment.amount)}</TableCell>
                          <TableCell>
                            <Chip 
                              label={payment.status === 'paid' ? 'Оплачен' : payment.status} 
                              color={payment.status === 'paid' ? 'success' : 'default'} 
                              size="small" 
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Alert severity="info">
                  По этой рассрочке еще не было платежей.
                </Alert>
              )}
            </>
          )}
        </Paper> */}
      </Box>
    </Container>
  );
};

function App() {
  const dispatch = useDispatch();
  const { loading, error, user, isAuthenticated } = useSelector(state => state.auth);
  
  // При загрузке приложения проверяем аутентификацию
  useEffect(() => {
    dispatch(fetchCurrentUser());
  }, [dispatch]);
  
  // Логирование информации о пользователе
  useEffect(() => {
    if (user) {
      console.log('Авторизованный пользователь:', user);
      console.log('Роль пользователя:', user.role);
      console.log('Админ флаг:', user.isAdmin);
    }
  }, [user]);
  
  // Ожидаем завершения загрузки
  if (loading && !error) {
    return <Loader />;
  }
  
  return (
    <Router>
      <div className="app">
      <Navbar />
      <main className="main-content">
        <Routes>
          {/* Маршруты аутентификации */}
            <Route path="/" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
            <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} />
            <Route path="/register" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Register />} />
          
          {/* Защищенные маршруты (для всех авторизованных пользователей) */}
            <Route path="/dashboard" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
            <Route path="/installments" element={<ProtectedRoute><UserInstallmentsList /></ProtectedRoute>} />
            <Route path="/installments/:id" element={<ProtectedRoute><InstallmentDetails /></ProtectedRoute>} />
            <Route path="/installments/:id/payments" element={<ProtectedRoute><PaymentList /></ProtectedRoute>} />
            <Route path="/installments/:id/payment" element={<ProtectedRoute><PaymentSimulation /></ProtectedRoute>} />
            <Route path="/create-installment" element={<ProtectedRoute><CreateInstallment /></ProtectedRoute>} />
            <Route path="/templates" element={<ProtectedRoute><TemplateSelection /></ProtectedRoute>} />
          <Route path="/calculator" element={<ProtectedRoute><PaymentCalculator /></ProtectedRoute>} />

          {/* Маршруты только для администраторов */}
            <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/admin/stats" element={<AdminRoute><Statistics /></AdminRoute>} />
          <Route path="/admin/users" element={<AdminRoute><UsersList /></AdminRoute>} />
          <Route path="/admin/templates" element={<AdminRoute><TemplatesList /></AdminRoute>} />
            <Route path="/admin/installments" element={<AdminRoute><InstallmentsList /></AdminRoute>} />
            <Route path="/admin/installments/:id" element={<AdminRoute><InstallmentDetails /></AdminRoute>} />
            <Route path="/admin/installments/:id/payments" element={<AdminRoute><PaymentsList /></AdminRoute>} />
            <Route path="/admin/payments" element={<AdminRoute><PaymentsList /></AdminRoute>} />
          
          {/* Редирект на главную для неизвестных путей */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
        <Notification />
      </div>
    </Router>
  );
}

export default App;
