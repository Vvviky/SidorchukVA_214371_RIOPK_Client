import React from 'react';
import { render, screen, act } from '@testing-library/react';
import { AuthProvider } from '../AuthContext';
import { authService } from '../../services/auth.service';

jest.mock('../../services/auth.service');

describe('AuthProvider', () => {
  const mockUser = {
    id: 1,
    email: 'test@example.com',
    role: 'user'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should provide initial state', () => {
    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    expect(screen.getByText('Loading: true')).toBeInTheDocument();
    expect(screen.getByText('User: null')).toBeInTheDocument();
  });

  it('should handle successful login', async () => {
    authService.login.mockResolvedValue({ token: 'test-token', user: mockUser });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const loginButton = screen.getByText('Login');
      loginButton.click();
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText(`User: ${JSON.stringify(mockUser)}`)).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBe('test-token');
  });

  it('should handle login error', async () => {
    authService.login.mockRejectedValue(new Error('Login failed'));

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const loginButton = screen.getByText('Login');
      loginButton.click();
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText('User: null')).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBeNull();
  });

  it('should handle successful registration', async () => {
    authService.register.mockResolvedValue({ token: 'test-token', user: mockUser });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const registerButton = screen.getByText('Register');
      registerButton.click();
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText(`User: ${JSON.stringify(mockUser)}`)).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBe('test-token');
  });

  it('should handle registration error', async () => {
    authService.register.mockRejectedValue(new Error('Registration failed'));

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const registerButton = screen.getByText('Register');
      registerButton.click();
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText('User: null')).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBeNull();
  });

  it('should handle logout', async () => {
    localStorage.setItem('token', 'test-token');

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const logoutButton = screen.getByText('Logout');
      logoutButton.click();
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText('User: null')).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBeNull();
  });

  it('should restore session from token', async () => {
    localStorage.setItem('token', 'test-token');
    authService.getCurrentUser.mockResolvedValue(mockUser);

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      // Wait for initial load
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText(`User: ${JSON.stringify(mockUser)}`)).toBeInTheDocument();
  });

  it('should handle session restoration error', async () => {
    localStorage.setItem('token', 'test-token');
    authService.getCurrentUser.mockRejectedValue(new Error('Session restoration failed'));

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      // Wait for initial load
    });

    expect(screen.getByText('Loading: false')).toBeInTheDocument();
    expect(screen.getByText('User: null')).toBeInTheDocument();
    expect(localStorage.getItem('token')).toBeNull();
  });
});

// Test component to access context values
const TestComponent = () => {
  const { user, loading, login, register, logout } = React.useContext(AuthProvider.context);

  return (
    <div>
      <div>Loading: {loading.toString()}</div>
      <div>User: {JSON.stringify(user)}</div>
      <button onClick={() => login('test@example.com', 'password123')}>Login</button>
      <button onClick={() => register('test@example.com', 'password123')}>Register</button>
      <button onClick={logout}>Logout</button>
    </div>
  );
}; 